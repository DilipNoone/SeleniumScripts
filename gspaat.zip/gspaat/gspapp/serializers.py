'''
from rest_framework import serializers
from .models import ModelGSPRequest, BinaryGroup, ModelSuffix

class ModelGSPRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModelGSPRequest
        fields = [ 'model_name', 'model_no', 'os_ver', 'chipset', 'rel_cycle', 'rel_plan', 'rel_type' , 'no_of_bin_groups' ]
'''