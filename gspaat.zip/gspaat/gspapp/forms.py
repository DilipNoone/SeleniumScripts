from django import forms
from django.forms import ModelForm, inlineformset_factory, modelformset_factory
from django.contrib.auth.forms import AuthenticationForm
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Div, Submit, HTML, ButtonHolder, Row, Field, LayoutObject,Fieldset
from .models import GSP, Category, LGSIDomainOwner, HQDomainOwner, SecurityPatchLevel, GSPECModel
from .models import ApplyGSP, ReleaseCycle, Chipset, SourceSASURL, OSName, ChipsetType
from .models import ModelRegister,ModelGSPRequest,ModelNumber

class LoginForm(AuthenticationForm):
    """
        This class is used to define the layout for Login Form using Django crispy form helper
    """
    remember_me = forms.BooleanField(required=True, initial=False)

    def __init__(self, *args, **kwargs):
        # username = forms.CharField(max_length=100)
        # password = forms.CharField(max_length=100)

        super(LoginForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_action = '.'
        self.helper.layout = Layout(
            Field('username', placeholder="Enter Username", autofocus=""),
            Field('password', placeholder="Enter Password"),
            Field('remember_me'),
            Submit('sign_in', 'Log in',
                   css_class="btn btn-lg btn-primary btn-block"),
        )


class GSPSearchForm(forms.Form):
    """
        This form is used to display the search form containing GSP fields.
        ModelChoiceField : Default widget for ModelChoiceField becomes impractical when the number of entries more than
        100. It takes one single argument and optional two arguments.
        single arg Queryset: A queryset of GSPModel objects from which the choices of field are derived and this is used
        to validate users selection.Its evaluated when form is rendered.
        second arg:empty_label
        ModelMultipleChoiceField :Default widget is SelectMultiple
        FormHelper:This class controls form rendering behaviour of the form passed to {% crispy %} tag.
        To to do we need to set its attributes and pass corresponding helper object to tag.
    """
    GSP_Category = forms.ModelChoiceField(label="Category", queryset=Category.objects.all(), empty_label="Select Category", required=False)
    GSP_SecurityPatchLevel = forms.ModelChoiceField(label="Security Patch level", queryset=SecurityPatchLevel.objects.all(), empty_label="Patch Level", required=False)
    GSP_Applicability = forms.CharField(label="Applicability", max_length=128, required=False)
    GSP_Description = forms.CharField(label="Description", max_length=300, required=False)
    GSP_GSP_ID = forms.CharField(label="Security Patch Level ID", max_length=200, required=False)
    GSP_LGSIDomainOwner = forms.ModelMultipleChoiceField(label="LGSIDomainOwner", queryset=LGSIDomainOwner.objects.all(), required=False)
    GSP_HQDomainOwner = forms.ModelMultipleChoiceField(label="HQDomainOwner", queryset=HQDomainOwner.objects.all(), required=False)
    GSP_OwnersShipStatus = forms.CharField(label="OwnersShipStatus", max_length=128, required=False)

    class Meta:
        model = GSP

    def __init__(self, *args, **kwargs):
        super(GSPSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'id-gspSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-md-2"
        self.helper.field_class = "col-md-10"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False
        self.helper.layout = Layout(
            Field('GSP_Category', placeholder="Enter GSP Category"),
            Field('GSP_SecurityPatchLevel', placeholder="Enter Security Patch level"),
            Field('GSP_GSP_ID', placeholder="Enter CVE ID"),
            Field('GSP_LGSIDomainOwner', placeholder="Select LGSIDomainOwner"),
            Field('GSP_HQDomainOwner', placeholder="Select HQ DomainOwner"),
            Field('GSP_OwnersShipStatus', placeholder="Enter OwnerShipStatus"),
        )


class GSPExtractSearchForm(forms.Form):
    """
        This form is used to filter and extract the Google Security patch domain confirmed list
    """
    GSPECModel_requestedTime = forms.DateTimeField(label="RequestedDate&Time", required=False)
    #extract_patch_level = forms.CharField(label="PatchLevel", max_length=100, required=False)
    GSPECModel_user = forms.CharField(label="UserName", max_length=100, required=False)

    class Meta:
        model = GSPECModel

    def __init__(self, *args, **kwargs):
        super(GSPExtractSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'form-gspExtractSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-md-2"
        self.helper.field_class = "col-md-10"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False

        self.helper.layout = Layout(
            Field('GSPECModel_requestedTime', placeholder="Enter Date & Time"),
            #Field('GSP_Extract_PatchLevel', placeholder="Enter Patch Level"),
            Field('GSPECModel_user', placeholder="Enter UserID"),
        )


class AddGSPForm(ModelForm):
    """
        This class is used to add Google security patch for all the fields defined in Model
        To define the same , field attribute is set to the special value __all__
    """

    class Meta:
        model = GSP
        fields = '__all__'


class ApplyGSPForm(ModelForm):
    """
        This class is used to define the form input fields to apply the google security patches for each user request
        from common SAS board:7620
    """
    helper = FormHelper()
    class Meta:
        model = ApplyGSP

        fields = ['model_name', 'model_no', 'os_name', 'chipset', 'patch_level_to_be_applied', 'rel_cycle',
                  'applied_gsp_count', 'from_sas_url', 'to_sas_url', 'def_src_manifest', 'from_sw_version',
                  'to_sw_version', 'description']
        #exclude = ['user', 'requested_time', 'applied_security_patch_level']


        # fields = '__all__'
        # fields = ('model_name', 'model_no')


class ModelRegisterForm(ModelForm):
    """
        This class is used to register the model information.
    """

    class Meta:
        model = ModelRegister
        exclude = ['model_leader']
        #fields = '__all__'


    @property
    def helper(self):
        helper = FormHelper()
        helper.form_tag = 'model_register_form'
        helper.layout = Layout(
            Fieldset(
               'Registered Model Details',
                #Row('model_leader' ),
                Row('model_name','model_no'),
                Row('os_name', 'os_version'),
                Row('chipset_type','chipset_name')
            )
        )

        return helper

'''
def unique_model_names():
    return [("","---------------")]+list(ModelRegister.objects.values_list('model_name','model_name').order_by('model_name').distinct())
'''



def unique_model_numbers():
    return list(ModelRegister.objects.values_list('model_no','model_no').order_by('model_no').distinct())

def unique_os_names():
    return list(ModelRegister.objects.values_list('os_name','os_name').order_by('os_name').distinct())

class ModelGSPRequestForm(ModelForm):
    """
        This class is used to define the form fields to raise the model GSP request.
    """
    iquery = ModelRegister.objects.values_list('model_name', flat=True).order_by('model_name').distinct()
    unique_model_names = [('', '-------')] + [(str(id), str(id)) for id in iquery]
    registered_model = forms.ChoiceField(label="Select Model Name",required=False, choices=unique_model_names,widget=forms.Select)
    #registered_model = forms.ChoiceField(required=False,choices=unique_values)
    #registered_model = forms.ChoiceField(choices=[],required=False)
    #modelquery = ModelRegister.objects.values_list('model_name',flat=True).order_by('model_name').distinct()
    #modelquery_choices = [("",'-------')] + [(model, model) for model in modelquery ]
    #registered_model = forms.ChoiceField(choices=modelquery_choices, required=False, widget=forms.Select())
    #registered_model = forms.ChoiceField(required=False, choices=unique_values, widget=forms.Select)
    #registered_model = forms.ModelChoiceField(queryset=ModelRegister.objects.values_list('model_name',flat=True).order_by('model_name').distinct())
    #registered_model = forms.ModelChoiceField(label="Choose Model Name",queryset=ModelRegister.objects.distinct().order_by('model_name'))
    registered_model_no = forms.ChoiceField(label="Select Model No", required=False,  widget=forms.SelectMultiple)
    #registered_model_os_name = forms.ChoiceField(label="Select OS Name", required=False, widget=forms.SelectMultiple)
    
    class Meta:
        model = ModelGSPRequest
        exclude = ['model_gsp_requester']

    def clean(self):
        super(ModelGSPRequestForm,self).clean()
        registered_model = self.cleaned_data.get('registered_model')
        print("type(registered_model):", type(registered_model))
        registered_model_no = self.cleaned_data.get('registered_model_no')
        print("type(registered_model):", type(registered_model_no))
        #registered_model_nos = ','.join(str(self.cleaned_data['registered_model_no']))
        print("clean Method:registered model", registered_model)
        print("clean Method :ModelGSPRequestForm:", registered_model_no)
        return self.cleaned_data
        


    #choices=[]
    def __init__(self, *args, **kwargs):
        #super(ModelGSPRequestForm, self).__init__(*args, **kwargs)
        super().__init__(*args, **kwargs)
        #self.form_tag = False
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset("Add Model GSP Request",
                     Row('registered_model','registered_model_no','registered_model_os_name','registered_chipset_type'
                         'registered_chipset_name','integrator','region','rel_cycle','rel_start_date','rel_end_date',
                         'rel_type','bingroup','base_os_fingerprint','mpss_build_id','tz_build_id',
                         'previous_approved_sas_board','previous_approved_manifest','select_model_suffix',
                         'cupss_group','cupss_name','previous_swv','current_swv','previous_swov','current_swov',
                         'previous_svn','current_svn','previous_rev','current_rev','fota_images_path')
                     )
            )
        #self.fields['registered_model'].choices = ModelRegister.objects.values_list('model_name','model_name').order_by('model_name').distinct()
        #self.fields['registered_model'].queryset =  ModelRegister.objects.values_list('model_name',flat=True).order_by('model_name').distinct()
        #self.fields['registered_model_no'].queryset = ModelNumber.objects.none()


        if 'registered_model' in self.initial: # If there is some form post data
        #if self.is_bound:
            print("form post data")
            try:
                    registered_model_id = int(self.data.get('registered_model'))
                    self.fields['registered_model_no'].queryset = ModelRegister.objects.filter(registered_model=registered_model_id).values_list('model_no',flat=True).order_by('model_no').distinct()
            except (ValueError,TypeError):
                pass # invalid input from the client ; ignore and use empty queryset
                print("invalid input from client")
        elif self.instance.pk:
            print(" post data with pk")
            self.fields['registered_model_no'].queryset = self.instance.registered_model.registered_model_no_set.order_by('registered_model_no')
        else:
            print("No post data")

ModelGSPRequestFormSet = modelformset_factory(ModelGSPRequest, form=ModelGSPRequestForm, extra=1, can_delete=True)

#ModelGSPRequestFormSet = inlineformset_factory(ModelRegister,ModelGSPRequest,form=ModelGSPRequestForm,extra=1)



class ModelRegisterSearchForm(forms.Form):
    """
        This class is used to display the search form for registered Model.
    """
    ModelRegister_User = forms.CharField(label="Model Registered User", max_length=100 , required=False)
    ModelRegister_model_name = forms.CharField(label="Registered Model Name",max_length=100, required=False)
    ModelRegister_model_no = forms.CharField(label="Registered Model No", max_length=100, required=False)
    ModelRegister_os_name = forms.ModelChoiceField(label="Registered Model OS Name", queryset=OSName.objects.all(),
                                             empty_label="Select OS Name",required=False)
    ModelRegister_chipset_type = forms.ModelChoiceField(label="Registered Chipset Type", queryset=ChipsetType.objects.all(),
                                                        empty_label="Select Chipset Type", required=False)
    ModelRegister_chipset_name = forms.ModelMultipleChoiceField(label="Registered Model Chipset", queryset=Chipset.objects.all(),
                                                      required=False)


    class Meta:
        model = ModelRegister

    def __init__(self, *args, **kwargs):
        super(ModelRegisterSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'form-ModelRegisterSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-md-2"
        self.helper.field_class = "col-md-10"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False

        self.helper.layout = Layout(
            Field('ModelRegister_User', placeholder="Enter UserID"),
            Field('ModelRegister_model_name', placeholder="Enter ModelName"),
            Field('ModelRegister_model_no', placeholder="Enter ModelNo"),
            Field('ModelRegister_os_name', placeholder="Enter OS Name"),
            Field('ModelRegister_chipset_type', placeholder="Enter Chipset Type"),
            Field('ModelRegister_chipset_name', placeholder="Enter Chipset Name"),
        )

class ModelGSPRequestSearchForm(forms.Form):
    """
        This class is used to display the search form for registered Model.
    """
    ModelGSPRequest_User = forms.CharField(label="Model Registered User", max_length=100 , required=False)
    ModelGSPRequest_model_name = forms.CharField(label="Registered Model Name",max_length=100, required=False)
    ModelGSPRequest_model_no = forms.CharField(label="Registered Model No", max_length=100, required=False)
    ModelGSPRequest_os_name = forms.ModelChoiceField(label="Registered Model OS Name", queryset=OSName.objects.all(),
                                             empty_label="Select OS Name",required=False)
    ModelGSPRequest_chipset_type = forms.ModelChoiceField(label="Registered Chipset Type", queryset=ChipsetType.objects.all(),
                                                        empty_label="Select Chipset Type", required=False)
    ModelGSPRequest_chipset_name = forms.ModelMultipleChoiceField(label="Registered Model Chipset", queryset=Chipset.objects.all(),
                                                      required=False)


    class Meta:
        model = ModelGSPRequest

    def __init__(self, *args, **kwargs):
        super(ModelGSPRequestSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'form-ModelGSPRequestSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-md-2"
        self.helper.field_class = "col-md-10"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False

        self.helper.layout = Layout(
            Field('ModelGSPRequest_User', placeholder="Enter UserID"),
            Field('ModelGSPRequest_model_name', placeholder="Enter ModelName"),
            Field('ModelGSPRequest_model_no', placeholder="Enter ModelNo"),
            Field('ModelGSPRequest_os_name', placeholder="Enter OS Name"),
            Field('ModelGSPRequest_chipset_type', placeholder="Enter Chipset Type"),
            Field('ModelGSPRequest_chipset_name', placeholder="Enter Chipset Name"),
        )


class ApplyGSPSearchForm(forms.Form):
    """
        This class is used to display the search form for ApplyGSP Model.
    """
    ApplyGSP_User = forms.CharField(label="Applied GSP User", max_length=100 , required=False)
    ApplyGSP_model_name = forms.CharField(label="Applied GSP Model Name",max_length=100, required=False)
    ApplyGSP_model_no = forms.CharField(label="Applied GSP Model No", max_length=100, required=False)
    ApplyGSP_os_name = forms.ModelChoiceField(label="Applied GSP OS Name", queryset=OSName.objects.all(),
                                             empty_label="Select OS Name",required=False)
    ApplyGSP_chipset = forms.ModelMultipleChoiceField(label="Applied GSP Chipset", queryset=Chipset.objects.all(),
                                                      required=False)
    ApplyGSP_rel_cycle = forms.ModelChoiceField(label="Applied GSP Release Cycle", queryset=ReleaseCycle.objects.all(),
                                                empty_label="Select Release Cycle", required=False)
    ApplyGSP_from_sas_url = forms.ModelChoiceField(label="Applied GSP From SASURL", queryset=SourceSASURL.objects.all(),
                                                   empty_label="Select From SASURL", required=False)
    ApplyGSP_to_sas_url = forms.URLField(label="Applied GSP To SASURL", required=False)

    class Meta:
        model = ApplyGSP

    def __init__(self, *args, **kwargs):
        super(ApplyGSPSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'form-applyGSPSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-md-2"
        self.helper.field_class = "col-md-10"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False

        self.helper.layout = Layout(
            Field('ApplyGSP_User', placeholder="Enter UserID"),
            Field('ApplyGSP_model_name', placeholder="Enter ModelName"),
            Field('ApplyGSP_model_no', placeholder="Enter ModelNo"),
            Field('ApplyGSP_chipset', placeholder="Enter Chipset"),
            Field('ApplyGSP_rel_cycle', placeholder="Enter Release Cycle"),
            Field('ApplyGSP_from_sas_url', placeholder="Enter From SASURL"),
            Field('ApplyGSP_to_sas_url', placeholder="Enter To SASURL"),
        )




