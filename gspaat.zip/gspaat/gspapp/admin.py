from django.contrib import admin
from .models import GSP, Category, LGSIDomainOwner, HQDomainOwner, GspOwnerShipStatus, SecurityPatchLevel, GSPECModel
from .models import ApplyGSP, OSName, Chipset,ChipsetType, SourceSASURL,ReleaseCycle,DefaultSrcManifest
from .models import ModelGSPRequest,BinaryGroup,ModelSuffix,Region,ReleaseType

# Register your models here.

"""
The ModelAdmin class is the representation of a model in the admin interface.
Usually these are stored in a file named admin.py in our Application.
"""


class GSPAdmin(admin.ModelAdmin):
    pass


" Register 'GSP' Model Class with a Model admin description"
admin.site.register(GSP, GSPAdmin)


class CategoryAdmin(admin.ModelAdmin):
    pass


admin.site.register(Category, CategoryAdmin)


class LGSIDomainOwnerAdmin(admin.ModelAdmin):
    pass


admin.site.register(LGSIDomainOwner, LGSIDomainOwnerAdmin)


class HQDomainOwnerAdmin(admin.ModelAdmin):
    pass


admin.site.register(HQDomainOwner, HQDomainOwnerAdmin)


class GspOwnerShipStatusAdmin(admin.ModelAdmin):
    pass


admin.site.register(GspOwnerShipStatus, GspOwnerShipStatusAdmin)


class SecurityPatchLevelAdmin(admin.ModelAdmin):
    pass


admin.site.register(SecurityPatchLevel, SecurityPatchLevelAdmin)


class GSPECModelAdmin(admin.ModelAdmin):
    pass
#    actions = [export_csv, export_xls, export_xlsx]


admin.site.register(GSPECModel, GSPECModelAdmin)


class ApplyGSPAdmin(admin.ModelAdmin):
    pass


admin.site.register(ApplyGSP, ApplyGSPAdmin)


class OSNameAdmin(admin.ModelAdmin):
    pass


admin.site.register(OSName, OSNameAdmin)


class ChipsetAdmin(admin.ModelAdmin):
    pass


admin.site.register(Chipset, ChipsetAdmin)


class SourceSASURLAdmin(admin.ModelAdmin):
    pass


admin.site.register(SourceSASURL, SourceSASURLAdmin)


class ReleaseCycleAdmin(admin.ModelAdmin):
    pass


admin.site.register(ReleaseCycle, ReleaseCycleAdmin)


class DefaultSrcManifestAdmin(admin.ModelAdmin):
    pass


admin.site.register(DefaultSrcManifest, DefaultSrcManifestAdmin)


class ModelGSPRequestAdmin(admin.ModelAdmin):
    pass


admin.site.register(ModelGSPRequest, ModelGSPRequestAdmin)


class BinaryGroupAdmin(admin.ModelAdmin):
    pass


admin.site.register(BinaryGroup, BinaryGroupAdmin)


class ModelSuffixAdmin(admin.ModelAdmin):
    pass


admin.site.register(ModelSuffix, ModelSuffixAdmin)


class ChipsetTypeAdmin(admin.ModelAdmin):
    pass


admin.site.register(ChipsetType,ChipsetTypeAdmin)

class RegionAdmin(admin.ModelAdmin):
    pass

admin.site.register(Region,RegionAdmin)


class ReleaseTypeAdmin(admin.ModelAdmin):
    pass


admin.site.register(ReleaseType,ReleaseTypeAdmin)


