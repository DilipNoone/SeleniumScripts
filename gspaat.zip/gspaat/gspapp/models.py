from __future__ import unicode_literals

from django.db import models
from django.utils import timezone


# Create your models here.

class GspOwnerShipStatus(models.Model):

    """
        This class is used to define corresponding HQ Owner and lgsi domain ownership status for each
        Google security patch.
    """

    GSP_OwnerShip_Status = models.CharField(max_length=128)

    def __str__(self):
        return self.GSP_OwnerShip_Status

    class Meta:
        verbose_name_plural = "GSP_OwnerShip_Status"


class HQDomainOwner(models.Model):

    """
        This class is used to define the HQ owner attribute for corresponding LGSI Domain owner.
    """

    HQ_Domain_Owner_name = models.CharField(max_length=128,unique=True)

    def __str__(self):
        return self.HQ_Domain_Owner_name

    class Meta:
        verbose_name_plural = "HQ_Domain_Owners"


class LGSIDomainOwner(models.Model):

    """
        This class is used to define the lgsi Owner attribute for each Google security patch.
        This is an intermediatory model associated with ManytoManyField using the through argument
        to point to the model that will act as an intermediary.
    """

    LGSI_Domain_Owner_name = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.LGSI_Domain_Owner_name

    class Meta:
        verbose_name_plural = "LGSI_Domain_Owners"


class Category(models.Model):
    """
        This class is used to define the category of each Google security patch.
    """

    category = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.category

    class Meta:
        verbose_name_plural = "Categories"

class OSName(models.Model):
    """
        This class is used to define the OS Name
    """
    osname = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.osname

    class Meta:
        verbose_name_plural = "OSNames"


class OSVersion(models.Model):
    """
        This class is used to define the OS version
    """
    osversion = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.osversion

    class Meta:
        verbose_name_plural = "OSVersions"


class Chipset(models.Model):
    """
        This class is used to define the chipset Names.
    """
    chipsetname = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.chipsetname

    class Meta:
        verbose_name_plural = "ChipsetDetails"


class ChipsetType(models.Model):
    """
        This class is used to define the chipset type [ QCT/MTK ]
    """
    chipsettype = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.chipsettype

    class Meta:
        verbose_name_plural = "ChipsetTypes"


class SourceSASURL(models.Model):
    """
        This class is used to define the Source SAS URL from which the Google security patches to be copied.
    """
    source_sas_url = models.URLField()

    def __str__(self):
        return self.source_sas_url

    class Meta:
        verbose_name_plural = "SourceSASURLDetails"


class ReleaseCycle(models.Model):
    """
        This class is used to choose the release cycle for which we need to apply google security patches.
    """
    release_cycle = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.release_cycle

    class Meta:
        verbose_name_plural = "ReleaseCycles"


class ReleaseType(models.Model):
    """
        This class is used to define the Release Type.
    """
    release_type = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.release_type

    class Meta:
        verbose_name_plural = "ReleaseTypes"


class Region(models.Model):
    """
        This class is used to select the region.
    """
    region = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.region

    class Meta:
        verbose_name_plural = "Regions"


class DefaultSrcManifest(models.Model):
    """
        This class is used to define the default source manifest to be selected while applyig Google security patches.
    """
    default_src_manifest = models.CharField(max_length=100,unique=True)

    def __str__(self):
        return self.default_src_manifest

    class Meta:
        verbose_name_plural = "DefaultSrcManifestDetails"


class SecurityPatchLevel(models.Model):
    """
     This class is used to define the security patch level for each Google security patch.
    """
    security_patch_level = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.security_patch_level

    class Meta:
        verbose_name_plural = "SecurityPatchLevels"


class BinaryGroup(models.Model):
    """
        This class is used to select binary group
    """

    binarygroup = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.binarygroup

    class Meta:
        verbose_name_plural = "BinaryGroups"


class ModelSuffix(models.Model):
    """
        This class is used to select Model Suffix
    """
    model_suffix = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.model_suffix

    class Meta:
        verbose_name_plural = "ModelSuffixes"


class GSP(models.Model):
    """
        By default ,Django gives each model the following field,an Automatic primary Key
        id = models.AutoField(primary_key=True)

        If You would like to specify custom primary key,just specify primary_key = true on one of your fields
        If Django sees you have explicitly set Field.primary_key it won't add the automatic id column.

        Each field type,except for ForeignKey,ManytoManyField,OneToOneField takes an optional first
        positional argument a verbose name.If verbose name is not given then Django will automatically
        create it using fields attribute name ,converting underscores to spaces.

        In case of FKey, ManytoManyField and OneToOneField Use the first argument to be a model class,so use
        the verbose_name keyword argument.

        This class is used to define the attributes for adding google security patch
    """

    Category = models.ForeignKey(Category, on_delete=models.CASCADE, verbose_name="GSP category")  
    Security_Patch_Level = models.ForeignKey(SecurityPatchLevel, on_delete=models.CASCADE, verbose_name="Patch Level")
    Applicability = models.CharField(max_length=128)
    Description = models.CharField(max_length=300)
    GSP_ID = models.CharField(max_length=200, default="")
    Function = models.CharField(max_length=128, default="", blank=True)
    LGSIDomainOwners = models.ManyToManyField(LGSIDomainOwner)
    HQDomainOwners = models.ManyToManyField(HQDomainOwner)
    Dependency = models.CharField(max_length=128, default="", blank=True)
    OwnersShipStatus = models.CharField(max_length=128, blank=True)

    class Meta:
        verbose_name_plural = "Google Security Patches"

    def __str__(self):
        return self.GSP_ID


class GSPECModel(models.Model):
    """
     This class is used to create the model for Google Security patch Confirmed List
     FileField: A file upload field
     If you are using default filesystem storage,the string value will be appended to MEDIA_ROOT path to form the location on the local file system
     where upload files are stored.
     Define MEDIA_URL as base public URL for that directory and ensure that this directory is writable by webserver's user account.
     DateTimeField :Automatically set the field to now when the object is first created. It is useful for creation of timestamps.
     auto_now used for "last-modified' timestamps . auto_now_add =true .
    """
    excelFile = models.FileField()
    created_info = models.BooleanField(default=False)
    requested_Time = models.DateTimeField(auto_now_add=True)
    # PatchLevel = models.CharField(max_length=128, default="")
    gsp_count = models.IntegerField(null=True)
    extract_filtered_model = models.ForeignKey(GSP, on_delete=models.CASCADE)
    user = models.CharField("User", max_length=128, default="")

    def __str__(self):
        return self.user + str(self.pk)


class ApplyGSP(models.Model):
    """
    This class is used to Apply the GoogleSecurityPatches when the user requested to apply the GSP
    """
    user = models.CharField("User", max_length=100, default="")
    model_name = models.CharField(max_length=100)
    model_no = models.CharField(max_length=100)
    os_name = models.ForeignKey(OSName, on_delete=models.CASCADE, verbose_name="os name",default=" ")
    chipset = models.ManyToManyField(Chipset)
    patch_level_to_be_applied = models.CharField(max_length=200, blank=True)
    rel_cycle = models.ForeignKey(ReleaseCycle, on_delete=models.CASCADE, verbose_name="Release Cycle")
    requested_time = models.DateTimeField(default=timezone.now)
    applied_gsp_count = models.IntegerField(null=True)
    applied_security_patch_level = models.TextField(default="")
    from_sas_url = models.ForeignKey(SourceSASURL, on_delete=models.CASCADE, verbose_name="Source SAS URL")
    to_sas_url = models.URLField()
    def_src_manifest = models.ManyToManyField(DefaultSrcManifest)
    # from_manifest = models.CharField(max_length=200)
    # to_manifest = models.CharField(max_length=200)
    from_sw_version = models.IntegerField(null=True)
    to_sw_version = models.IntegerField(null=True)
    description = models.CharField(max_length=200)

    class Meta:
        verbose_name_plural = "ApplyGSPPatches"

    def __str__(self):
        return self.user + str(self.pk)


class ModelNumber(models.Model):
    """
            This class is used to
    """
    model_no = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.model_no

    class Meta:
        verbose_name_plural = "ModelNumbers"


class OSNames(models.Model):
    """
            This class is used to select the OS Names
    """
    model_nos = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.os_names

    class Meta:
        verbose_name_plural = "OSNames"


class ModelRegister(models.Model):
    """
        This class is used to register the model.
    """
    FLOAT_CHOICES = [[float(x), float(x)] for x in range(1, 21)]
    model_leader = models.CharField("Model leader", max_length=128)
    model_name = models.CharField(max_length=128, verbose_name="ModelName")
    model_no = models.CharField(max_length=128, verbose_name="ModelNo")
    os_name = models.ForeignKey(OSName, on_delete=models.CASCADE, verbose_name="OSName",default=" ")
    os_version = models.FloatField(choices=FLOAT_CHOICES)
    chipset_type = models.ForeignKey(ChipsetType,on_delete=models.CASCADE, verbose_name="chipsetType")
    chipset_name = models.ManyToManyField(Chipset)

    class Meta:
        verbose_name_plural = "ModelRegisteredList"

    def __str__(self):
        return self.model_name


class ModelGSPRequest(models.Model):
    """
        This class is used to raise Model GSP request.
    """

    #FLOAT_CHOICES = [[float(x),float(x)] for x in range(1,21)]
    #registered_model = models.ForeignKey(ModelRegister,on_delete=models.CASCADE, verbose_name="ModelName")
    #model_nos_for_reg_model = models.ManyToManyField(ModelNumber,default="")
    #registered_model_no = models.CharField(max_length=128, verbose_name="ModelNo",default=" ")
    #registered_os_name = models.ForeignKey(OSName, on_delete=models.CASCADE, verbose_name="OSName",default=" ")
    #registered_os_version = models.FloatField(choices=FLOAT_CHOICES)
    #registered_model_name = models.CharField(max_length=128,default="")
    registered_model = models.CharField(max_length=128, verbose_name="Select Model Name")
    #registered_model_no = models.ManyToManyField(ModelNumber, default="")
    registered_model_os_name = models.ManyToManyField(OSName)
    #registered_model_os_name = models.ManyToManyField(max_length=128, verbose_name="Select OS Name")
    registered_model_no = models.CharField(max_length=128, verbose_name="Select Model No",default="")
    #registered_model_os_name = models.CharField(max_length=128, verbose_name="Select OS Name")
    #registered_model_os_version = models.FloatField(choices=FLOAT_CHOICES,default="")


    registered_chipset_type = models.ForeignKey(ChipsetType, on_delete=models.CASCADE, verbose_name="chipsetType",default=" ")
    registered_chipset_name = models.ManyToManyField(Chipset)

    model_gsp_requester = models.CharField("Model GSP Requester", max_length=128,default=" ")
    integrator = models.CharField("Integrator", max_length=100,default=" ")
    region = models.ForeignKey(Region, on_delete=models.CASCADE, verbose_name="Region",default=" ")
    rel_cycle = models.ForeignKey(ReleaseCycle, on_delete=models.CASCADE, verbose_name="Release Cycle",default=" ")
    rel_start_date = models.DateField(default=" ")
    rel_end_date = models.DateField(default=" ")
    rel_type = models.ForeignKey(ReleaseType, on_delete=models.CASCADE, verbose_name="Release Type",default=" ")
    bingroup = models.ForeignKey(BinaryGroup, on_delete=models.CASCADE, verbose_name="BinaryGroup", default=" ")
    base_os_fingerprint = models.CharField(max_length=200, verbose_name="Base OS FingerPrint",blank=True,null=True)
    mpss_build_id = models.CharField(max_length=200,default=" ")
    tz_build_id = models.CharField(max_length=200,default=" ")
    previous_approved_sas_board = models.CharField(max_length=128,default=" ")
    previous_approved_manifest = models.CharField(max_length=128,default=" ")
    select_model_suffix = models.ForeignKey(ModelSuffix, on_delete=models.CASCADE,default=" ")
    cupss_group = models.CharField(max_length=128,verbose_name="CUPSS Group",default=" ")
    cupss_name = models.CharField(max_length=128,verbose_name="CUPSS Name",default=" ")
    previous_swv = models.CharField(max_length=128,default=" ")
    current_swv = models.CharField(max_length=128,default=" ")
    previous_swov = models.CharField(max_length=128,default=" ")
    current_swov = models.CharField(max_length=128,default=" ")
    previous_svn = models.CharField(max_length=128,default=" ")
    current_svn = models.CharField(max_length=128,default=" ")
    previous_rev = models.CharField(max_length=128,default=" ")
    current_rev = models.CharField(max_length=128, default=" ")
    fota_images_path = models.CharField(max_length=200,default=" ")
    #requested_Time = models.DateTimeField(auto_now_add=True,default=" ")

    class Meta:
        verbose_name_plural = "ModelGSPRequests"

    def __str__(self):
        return self.model_gsp_requester + self.integrator + str(self.pk)

