from __future__ import unicode_literals

from django.shortcuts import get_object_or_404, render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .forms import LoginForm, AddGSPForm, GSPSearchForm, GSPExtractSearchForm, ApplyGSPForm, ApplyGSPSearchForm
from .forms import ModelRegisterForm,ModelRegisterSearchForm,ModelGSPRequestForm,ModelGSPRequestSearchForm,ModelGSPRequestFormSet
from .models import GSP, Category, SecurityPatchLevel, LGSIDomainOwner, HQDomainOwner, GSPECModel, GspOwnerShipStatus
from .models import ApplyGSP,Chipset,ReleaseCycle,SourceSASURL
from .models import ModelRegister,OSName,ModelGSPRequest,ChipsetType
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.views.generic import ListView
from django.contrib.auth import authenticate, login, logout
from django.core import serializers
from .tasks import excelextract_sendmail
from django.views.generic.edit import CreateView,UpdateView
from django.urls import reverse_lazy
from django.db import transaction
#from rest_framework import viewsets
#from .serializers import ModelGSPRequestSerializer
#from rest_framework.renderers import TemplateHTMLRenderer
#from rest_framework.response import Response
#from rest_framework.views import APIView


# from django.template.response import TemplateResponse

# Create your views here.


def login_view(request):
    logout(request)
    page_title = "GSPTracker"
    loginpage_heading = "Google Security Patch Tracker"

    #   If this is a post request we need to process the form data

    username = password = ''
    redirect_to = request.GET.get('next', '/gspapp/')
    print("redirect_to:", redirect_to)
    form = LoginForm()

    if request.POST:
        print("check if request is POST")
        form = LoginForm(request.POST)

        username = request.POST['username']
        password = request.POST['password']

        print("username:", username)
        print("password:", password)

        '''authenticate(request=None, **credentials)
        Use authenticate to verify a set of credentials .It takes credentials as keyword arguments.username and password
        for default case, check them against each authentication backend and returns a user object if the credentials are
        valid for a backend.'''
        user = authenticate(request, username=username, password=password)
        
        print("request.user object:", request.user)
        print("is anonymous:", request.user.is_anonymous)
        print("is authenticated:", request.user.is_authenticated)

        if user is not None:
            print("logged in user is not None and user is active:")
            '''If you have an authenticated user you want to attach to current session - this is done with login function
            login saves used id in the session, using Django sessions framework '''
            login(request, user)

            remember_me = request.POST.get('remember_me', False)

            if remember_me == "on":
                ONE_MONTH = 30 * 24 * 60 * 60
                expiry = getattr(settings, "KEEP_LOGGED_DURATION", ONE_MONTH)
                request.session.set_expiry(expiry)
            else:
                request.session.set_expiry(0)

            return HttpResponseRedirect(redirect_to)

    context = {'form': form, 'page_title': page_title, 'loginpage_heading': loginpage_heading}
    return render(request, 'login.html', context)


@login_required(login_url='/gspapp/')
def logon_view(request, id=None):
    print("Inside logon_view:")

    page_title = "GSPTracker"

    if request.method == 'POST':
        form = LoginForm(request.POST)
        print("when request method is POST inside logon_view request:")

        if form.is_valid():
            print("checked whether requested form is valid or not:")
            form.save()
            return HttpResponseRedirect('/gspapp/')
    else:
        print("when request method is GET:")
        # form = GSPSearchForm(request.GET)
        # context = {'form': form}
        context = {'page_title': page_title}
        return render(request, 'GSPTracker.html', context)


@login_required(login_url='/gspapp/')
def addgsp(request, id=None):
    """
    :param request: Accept http request
    :param id: if has id ,perform edit/update action else
    :return: render the template with the retrieved data
    :description:  This method is used to add Google Security Patch if it is GET request and edit or modify the existing
        Google security patch from GSP ListView if it is POST request.

    """
    print("ID Inside Add Google Security Patch:", id)

    if id:
        action = 'edit'
        '''
            Calling get() on a given model Manager ,but it raises Http404 instead of the model Does not Exist exception.
        '''
        model = get_object_or_404(GSP, pk=id)

    else:
        action = 'add'
        model = GSP()

    message = ""

    if request.method == 'POST':
        print("Inside addgsp during POST request")
        form = AddGSPForm(request.POST, instance=model)

        if form.is_valid():
            print("Checking whether form is valid or not")
            form.save()
            return HttpResponseRedirect('/gspapp/AddGSP')

    else:
        print("Inside addgsp during GET request")
        form = AddGSPForm(instance=model)

    context = {'form': form, 'Message': message, 'action': action}
    return render(request, 'AddGSP.html', context)


@login_required(login_url='/gspapp/')
def apply_gsp_request_form(request, id=None):
    """
    :param request: Accept http request
    :param id: Id of Requested User record
    :return: http response
    """
    print("Inside Apply Google Security Patch Form:", id)
    print("request:", request.method)
    print("request.GET:",request.GET)
    #load_input_value = request.GET.get('loaddata')
    #print("load input value:",load_input_value)

    if id:
        action = 'edit'
        model = get_object_or_404(ApplyGSP, pk=id)
    else:
        action = 'submit'
        model = ApplyGSP()

    message = ""


    if request.method == 'POST':
        form = ApplyGSPForm(request.POST, instance=model)

        if form.is_valid():
            new_apply_gsp_request = form.save(commit=False)
            new_apply_gsp_request.user = request.user.username
            new_apply_gsp_request.save()
            form.save_m2m()
            return HttpResponseRedirect('/gspapp/ApplyGSPList')

    else:
        print("when the request is GET ,call ApplyGSPForm ")
        form = ApplyGSPForm(instance=model)
        apply_gsp_model_data = serializers.serialize("json", ApplyGSP.objects.all())
        print("apply_gsp_model_Data:",apply_gsp_model_data)

        context = {'form': form,'apply_gsp_model':apply_gsp_model_data, 'Message': message, 'action': action}
    if action == 'edit':
        print("action is edit")
        return render(request, 'EditApplyGSP.html', context)
    else:
        print("action is submit")
        return render(request, 'ApplyGSP.html', context)


@login_required(login_url='/gspapp/')
def model_register_form(request, id=None):
    """
    :param request: Accept http request
    :param id: Id of Requested record
    :return: http response
    """
    print("Inside Model Register Form:", id)

    if id:
        action = 'edit'
        model = get_object_or_404(ModelRegister, pk=id)
    else:
        action = 'submit'
        model = ModelRegister()

    message = ""

    if request.method == 'POST':
        print("when the request is POST ,In ModelRegisterForm")
        form = ModelRegisterForm(request.POST, instance=model)

        if form.is_valid():
            new_model_register_request = form.save(commit=False)
            new_model_register_request.model_leader = request.user.username
            new_model_register_request.save()
            form.save_m2m()
            return HttpResponseRedirect('/gspapp/ModelRegisterList')

    else:
        print("when the request is GET ,In ModelRegisterForm")
        form = ModelRegisterForm(instance=model)
        register_model_data = serializers.serialize("json", ModelRegister.objects.all())
        print("register_model_Data:", register_model_data)
        #apply_gsp_model_data = serializers.serialize("json", ApplyGSP.objects.all())
        #print("apply_gsp_model_Data:",apply_gsp_model_data)

        context = {'form': form,'Message': message,'register_model_data':register_model_data, 'action': action}

    context = {'form': form,'register_model_data':register_model_data,'Message': message, 'action': action}
    return render(request, 'ModelRegister.html', context)

'''
def create_model_gsp_request_form(request,id=None):
    print("create_model_gsp_request_form:", id)

    if id:
        action = 'edit'
        model = get_object_or_404(ModelGSPRequest, pk=id)
    else:
        action = 'submit'
        model = ModelGSPRequest()

    message = ""

    if request.method == 'POST':
        print("when the request is POST ,In ModelGSPRequestForm")
        form = ModelGSPRequestForm(request.POST, instance=model)

        if form.is_valid():
            new_model_gsp_request = form.save(commit=False)
            new_model_gsp_request.model_gsp_requester = request.user.username
            new_model_gsp_request.save()
            form.save_m2m()
            return HttpResponseRedirect('/gspapp/ModelGSPRequestList')

    else:
        print("when the request is GET ,In ModelGSPRequestForm")
        form = ModelGSPRequestForm(instance=model)
        registered_model_details = serializers.serialize("json", ModelRegister.objects.all())
        print("registered_model_details:", registered_model_details)

        context = {'form': form,'registered_model_data':registered_model_details,'Message': message, 'action': action}

    #context = {'form': form, 'registered_model_data':registered_model_details,'Message': message, 'action': action}
    return render(request, 'ModelGSP.html', context)

'''
'''
class ModelGSPRequest(APIView):
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'ModelGSPRequest.html'

    def get(self, request, pk):
        model_gsp_request = get_object_or_404(ModelGSPRequest, pk=pk)
        serializer = ModelGSPRequestSerializer(model_gsp_request)
        return Response({'serializer': serializer, 'model_gsp_request': model_gsp_request})

    def post(self, request, pk):
        model_gsp_request = get_object_or_404(ModelGSPRequest, pk=pk)
        serializer = ModelGSPRequestSerializer(model_gsp_request, data=request.data)
        if not serializer.is_valid():
            return Response({'serializer': serializer, 'model_gsp_request': model_gsp_request})
        serializer.save()
        return redirect('ModelGSPRequestList')
'''
'''
class ModelGSPRequestApi(viewsets.ModelViewSet):
    queryset = ModelGSPRequest.objects.all()
    serializer_class = ModelGSPRequestSerializer
'''

def gsp_extract(request):

    """
    :param request: View that accepts http request when we click on "yes" button to perform sending email in background
           value: value which is received from template
    :return: Redirect to Google Security patch Extract Confirmed List Page
    """
    print("Inside gsp_extract view:")

    print("request:", request)
    print("url query string:", request.GET)

    gsp_filter_queryset = GSP.objects.all().order_by('-pk')

    print(" Before applying filter gsp_filter_queryset:", gsp_filter_queryset)
    print("no of records before applying filtered queryset:", gsp_filter_queryset.count())
    print("Display Applied Filter:", request.GET.urlencode())

    for item in request.GET:
        key = item
        value = request.GET.get(item)

        if key == "GSP_Category" and value:
            gsp_category_to_search = Category.objects.get(id=value)
            gsp_filter_queryset = gsp_filter_queryset.filter(Category__category__icontains=gsp_category_to_search)

        if key == "GSP_SecurityPatchLevel" and value:
            patch_level_to_search = SecurityPatchLevel.objects.get(id=value)
            gsp_filter_queryset = gsp_filter_queryset.filter(Security_Patch_Level__security_patch_level__icontains=patch_level_to_search)

        if key == "GSP_GSP_ID" and value:
            gsp_filter_queryset = gsp_filter_queryset.filter(GSP_ID__contains=value)

        if key == "GSP_LGSIDomainOwner" and value:
            lgsi_domain_to_search = LGSIDomainOwner.objects.get(id=value)
            gsp_filter_queryset = gsp_filter_queryset.filter(LGSIDomainOwners__LGSI_Domain_Owner_name__contains=lgsi_domain_to_search)

        if key == "GSP_HQDomainOwner" and value:
            hq_domain_to_search = HQDomainOwner.objects.get(id=value)
            gsp_filter_queryset = gsp_filter_queryset.filter(HQDomainOwners__HQ_Domain_Owner_name__icontains=hq_domain_to_search)

        if key == "GSP_OwnersShipStatus" and value:
            gsp_filter_queryset = gsp_filter_queryset.filter(OwnersShipStatus__icontains=value)

    gsp_filtered_records_count = gsp_filter_queryset.count()

    print("no of records in filtered queryset:", gsp_filter_queryset.count())
    print("After applying filter gsp_first_queryset:", gsp_filter_queryset)

    '''
    for i in range(gsp_filtered_records_count):
        extract_filter_list = GSPECModel()
        extract_filter_list.extract_filtered_model = gsp_filter_queryset[i]
        extract_filter_list.user = request.user.username
        extract_filter_list.gsp_count = gsp_filter_queryset.count()
     extract_filter_list.save()
    '''
    extract_filter_list = GSPECModel()
    extract_filter_list.extract_filtered_model = gsp_filter_queryset[gsp_filtered_records_count-1]
    extract_filter_list.user = request.user.username
    extract_filter_list.gsp_count = gsp_filter_queryset.count()
    extract_filter_list.save()

    # print("domain in gsp_extract:", domain)
    # excelextract_sendmail.delay(url_query_string, extract_filter_list, list(gsp_filter_queryset))
    # excelextract_sendmail.delay(list(gsp_filter_queryset))
    # excelextract_sendmail.delay(extract_filter_list.id)
    print("Calling delay function from gsp_extract method:")
    excelextract_sendmail.delay(extract_filter_list=extract_filter_list.pk,
                                gsp_filter_records_id_list=list(gsp_filter_queryset.values_list('pk', flat=True)))

    return HttpResponseRedirect('/gspapp/GSPECList')


class GSPDCList(ListView):

    """
        This view is used to display the list of added Google security Patches using ListView to get the domain confirmation.
        paginate_by:An integer representing how many objects should display per page.
        queryset:It is list of items for a given model.Querysets allow us to read data from the database, filter it and read it.
        get_queryset():Get the list of items for this view. This must be an iterable and may be a queryset
        get_context_data: Returns context data to display list of objects
        context_object_name:Designates name of the variable to use in the context
        template_name:It is the name of template to load and render to inform the view which template to use.
        This template will be rendered against a context containing a variable called object_list that contains all
        the GSP
        filter: Returns a new query set containing objects that match the given loop up parameters
        i contains: Case insensitive containment test

    """

    print("Inside GSP Tracker List View:")
    model = GSP
    form_class = GSPSearchForm

    context_object_name = 'gspatches'   # Template variable used to access the list of google security patches
    template_name = "GSPDCList.html"
    paginate_by = 8
    gspatches = []
    form = form_class()

    def get_queryset(self):
        """
            Returns the query set that will be used to retrieve the object that this view will display.
            By default, get_queryset returns the value of the queryset attribute if it is set otherwise it
            constructs a Queryset by calling the all() method on model attributes default manager.
            Get the list of items for this view . This must be an iterable and may be a queryset.
        """
        # self.Category = get_object_or_404(GSP, name=self.kwargs['Category'])

        print("Inside GSPDCList::getqueryset")

        gsp_list_queryset = GSP.objects.all().order_by('-pk')

        print("self.request.GET:", self.request.GET)

        """ 
            request.GET is a dictionary like object containing all GET request parameters.
            
            The method get() returns a value for the given key if key is in the dictionary.
            If key is not available then return default value none.
            
            request.GET.get() is a combination of above two using which key/values of a GET request can be accessed.
        """

        for item in self.request.GET:
            print("self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            print("Key:", key)
            print("value:", value)

            if key == "GSP_Category" and value:
                gsp_category_to_search = Category.objects.get(id=value)
                gsp_list_queryset = gsp_list_queryset.filter(Category__category__icontains=gsp_category_to_search)

            if key == "GSP_SecurityPatchLevel" and value:
                patch_level_to_search = SecurityPatchLevel.objects.get(id=value)
                gsp_list_queryset = gsp_list_queryset.filter(Security_Patch_Level__security_patch_level__icontains=patch_level_to_search)

            #   if key == "GSP_Applicability" and value:
            #    gsp_list_queryset = gsp_list_queryset.filter(Applicability__icontains=value)

            #   if key == "GSP_Description" and value:
            #    gsp_list_queryset = gsp_list_queryset.filter(Description__icontains=value)

            if key == "GSP_GSP_ID" and value:
                gsp_list_queryset = gsp_list_queryset.filter(GSP_ID__exact=value)

            if key == "GSP_LGSIDomainOwner" and value:
                lgsi_domain_to_search = LGSIDomainOwner.objects.get(id=value)
                gsp_list_queryset = gsp_list_queryset.filter(LGSIDomainOwners__LGSI_Domain_Owner_name__icontains=lgsi_domain_to_search)

            if key == "GSP_HQDomainOwner" and value:
                hq_domain_to_search = HQDomainOwner.objects.get(id=value)
                gsp_list_queryset = gsp_list_queryset.filter(HQDomainOwners__HQ_Domain_Owner_name__icontains=hq_domain_to_search)

            if key == "GSP_OwnersShipStatus" and value:
                gsp_list_queryset = gsp_list_queryset.filter(OwnersShipStatus__icontains=value)

        print("gsp_list_queryset:", gsp_list_queryset)
        print("count of gsp_list_queryset:", gsp_list_queryset.count())

        return gsp_list_queryset

    def get_context_data(self, **kwargs):
        """
        :param kwargs: Base implementation of this method requires that self.object attribute to be set by the view.

               Calls the base implementation to first to get a context.
            Generally ,get_context_data will merge the context data of all parent classes with those of current class.
            To preserve this behaviour in your own classes where we want to alter the context , we should be sure to call
            the context on the super class

        :return: Returns context data for displaying the list of objects.
              It returns a dictionary with the contents:
              .object : The object that this view is displaying (self.object)
              context_object_name : self.object will also be stored under the name returned by get_context_object_name(),
              which defaults to the lower cased version of the model name.
        """

        print("Inside GSPDCList::get_context_data")

        context = super(GSPDCList, self).get_context_data(**kwargs)
        context.update(**kwargs)

        context['form'] = GSPSearchForm(self.request.GET)
        searchq = ""

        for item in self.request.GET:
            print("GSPDCList::self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            print("key:",key)
            print("value:",value)

            if key == "page":
                continue

            searchq += "%s=%s&" % (key, value)
            print("searchq in GSPDCListView inside for loop:", searchq)

        print("searchq in GSPDCListView:", searchq)
        context['searchq'] = searchq
        return context


class GSPECList(ListView):
    """
     A View to extract list of Confirmed Google Security patches.
    :param : Google security patch confirmed list view accepting http request
    :return: list of items for the specified filter
    """
    print("Inside GSPECList View:")

    model = GSPECModel
    form_class = GSPExtractSearchForm

    context_object_name = 'extract_gsp_list_info'  # Template variable used to extract gsp list information
    template_name = "GSPECList.html"
    paginate_by = 8

    extract_gsp_list_info = []
    form = form_class()

    def get_queryset(self):
        """
          Get the list of requested GSP items for a given query set.
          :return: Return GSP extract list .
        """

        print("GSPECList:getqueryset")
        gsp_extract_list_queryset = GSPECModel.objects.all().order_by('-pk')

        for item in self.request.GET:
            key = item
            value = self.request.GET.get(item)

            if key == "GSPECModel_requestedTime" and value:
                gsp_extract_list_queryset = gsp_extract_list_queryset.filter(requested_Time__contains=value)

            if key == "GSPECModel_user" and value:
                gsp_extract_list_queryset = gsp_extract_list_queryset.filter(user__icontains=value)

        return gsp_extract_list_queryset

    def get_context_data(self, **kwargs):
        """
           :param kwargs: Base implementation of this method requires that self.object attribute to be set by the view.

           Calls the base implementation to first to get a context.
           Generally ,get_context_data will merge the context data of all parent classes with those of current class.
           To preserve this behaviour in your own classes where we want to alter the context , we should be sure to call
           the context on the super class.

           :return: Returns context data for displaying the list of objects.
           It returns a dictionary with the contents:
           .object : The object that this view is displaying (self.object)
           context_object_name : self.object will also be stored under the name returned by get_context_object_name(),
           which defaults to the lower cased version of the model name.
        """

        print("GSPECList:getContextData")
        context = super(GSPECList, self).get_context_data(**kwargs)
        context.update(**kwargs)

        context['form'] = GSPExtractSearchForm(self.request.GET)
        searchq = ""

        for item in self.request.GET:
            print("GSPECList:self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            if key == "page":
                continue

            searchq += "%s=%s&" % (key, value)

        print("searchq in GSPECListView:", searchq)
        context['searchq'] = searchq
        return context


class ModelRegisterList(ListView):
    """
        This view is used to display the registered model details in list view.
        paginate_by:An integer representing how many objects should display per page.
        queryset:It is list of items for a given model.Querysets allow us to read data from the database, filter it and read it.
        get_queryset():Get the list of items for this view. This must be an iterable and may be a queryset
        get_context_data: Returns context data to display list of objects
        context_object_name:Designates name of the variable to use in the context
        template_name:It is the name of template to load and render to inform the view which template to use.
        This template will be rendered against a context containing a variable called object_list that contains all
        the registered model details.
        filter: Returns a new query set containing objects that match the given loop up parameters
        i contains: Case insensitive containment test
    """

    print("Inside Model Register List View:")
    model = ModelRegister
    form_class = ModelRegisterSearchForm

    context_object_name = 'registeredmodels'  # Template variable used to access the list of registered model information
    template_name = "ModelRegisterList.html"
    paginate_by = 8
    gspatches = []
    form = form_class()

    def get_queryset(self):
        """
            Returns the query set that will be used to retrieve the object that this view will display.
            By default, get_queryset returns the value of the queryset attribute if it is set otherwise it
            constructs a Queryset by calling the all() method on model attributes default manager.
            Get the list of items for this view . This must be an iterable and may be a queryset.
        """
        # self.Category = get_object_or_404(GSP, name=self.kwargs['Category'])

        print("Inside ModelRegister::getqueryset")

        model_register_list_queryset = ModelRegister.objects.all().order_by('-pk')

        print("self.request.GET:", self.request.GET)

        """ 
            request.GET is a dictionary like object containing all GET request parameters.

            The method get() returns a value for the given key if key is in the dictionary.
            If key is not available then return default value none.

            request.GET.get() is a combination of above two using which key/values of a GET request can be accessed.
        """

        for item in self.request.GET:
            print("self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            print("Key:", key)
            print("value:", value)

            if key == "ModelRegister_User" and value:
                model_register_list_queryset = model_register_list_queryset.filter(model_leader__icontains=value)

            if key == "ModelRegister_model_name" and value:
                model_register_list_queryset = model_register_list_queryset.filter(model_name__icontains=value)

            if key == "ModelRegister_model_no" and value:
                model_register_list_queryset = model_register_list_queryset.filter(model_no__icontains=value)

            if key == "ModelRegister_os_name" and value:
                os_name_to_search = OSName.objects.get(id=value)
                model_register_list_queryset = model_register_list_queryset.filter(
                    os_name__osname__icontains=os_name_to_search)

            if key == "ModelRegister_chipset_type" and value:
                chipset_type_to_search = ChipsetType.objects.get(id=value)
                model_register_list_queryset = model_register_list_queryset.filter(
                    chipset_type__chipsettype__icontains=chipset_type_to_search)

            if key == "ModelRegister_chipset_name" and value:
                chipset_name_to_search = Chipset.objects.get(id=value)
                model_register_list_queryset = model_register_list_queryset.filter(
                    chipset_name__Chipset__icontains=chipset_name_to_search)

        return model_register_list_queryset

    def get_context_data(self, **kwargs):
        """
        :param kwargs: Base implementation of this method requires that self.object attribute to be set by the view.

               Calls the base implementation to first to get a context.
            Generally ,get_context_data will merge the context data of all parent classes with those of current class.
            To preserve this behaviour in your own classes where we want to alter the context , we should be sure to call
            the context on the super class

        :return: Returns context data for displaying the list of objects.
              It returns a dictionary with the contents:
              .object : The object that this view is displaying (self.object)
              context_object_name : self.object will also be stored under the name returned by get_context_object_name(),
              which defaults to the lower cased version of the model name.
        """

        print("Inside ModelRegisterList::get_context_data")

        context = super(ModelRegisterList, self).get_context_data(**kwargs)
        context.update(**kwargs)

        context['form'] = ModelRegisterSearchForm(self.request.GET)
        searchq = ""

        for item in self.request.GET:
            print("ModelRegisterSearchForm::self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            print("key:", key)
            print("value:", value)

            if key == "page":
                continue

            searchq += "%s=%s&" % (key, value)
            print("searchq in ModelRegisterListView inside for loop:", searchq)

        print("searchq in ModelRegisterListView:", searchq)
        context['searchq'] = searchq
        return context


class ModelGSPRequestCreate(CreateView):
    """
        For details:https://docs.djangoproject.com/en/3.0/ref/class-based-views/generic-editing/
        A view that displays a ModelGSPRequest form for creating and object,redisplaying the form with validation errors(if any)
        and saving the object
    """
    model = ModelRegister
    fields = ['model_name', 'model_no', 'os_name', 'os_version', 'chipset_type', 'chipset_name']
    #form_class = ModelGSPRequestForm                 # The form class to instantiate
    template_name = 'ModelGSPRequest.html'
    #success_url = reverse_lazy('ModelGSPRequestList')  # success_url:The URL to redirect when the form is successfully processed.

    def get_context_data(self, **kwargs):
        data = super(ModelGSPRequestCreate,self).get_context_data(**kwargs)

        if self.request.POST:
            data['modelgsprequests'] = ModelGSPRequestFormSet(self.request.POST)
        else:
            data['modelgsprequests'] = ModelGSPRequestFormSet()

        return data

    def form_valid(self,form):
        context = self.get_context_data()
        modelgsprequests = context['modelgsprequests']
        with transaction.atomic():
            self.object = form.save()

            if modelgsprequests.is_valid():
                modelgsprequests.instance = self.object
                modelgsprequests.save()

        return super(ModelGSPRequestCreate).form_valid(form)


class ModelGSPRequestUpdate(UpdateView):
    """
        For details:https://docs.djangoproject.com/en/3.0/ref/class-based-views/generic-editing/
        A view that displays a ModelGSPRequest form for creating and object,redisplaying the form with validation errors(if any)
        and saving the object
    """
    model = ModelRegister
    fields = ['model_name', 'model_no', 'os_name', 'os_version', 'chipset_type', 'chipset_name']
    #form_class = ModelGSPRequestForm  # The form class to instantiate
    template_name = 'ModelGSPRequest.html'
    #success_url = reverse_lazy('ModelGSPRequestList')  # success_url:The URL to redirect when the form is successfully processed.

    def get_context_data(self, **kwargs):
        data = super(ModelGSPRequestUpdate, self).get_context_data(**kwargs)

        if self.request.POST:
            data['modelgsprequests'] = ModelGSPRequestFormSet(self.request.POST,instance=self.object)
        else:
            data['modelgsprequests'] = ModelGSPRequestFormSet(instance=self.object)

        return data

    def form_valid(self, form):
        context = self.get_context_data()
        modelgsprequests = context['modelgsprequests']
        with transaction.atomic():
            self.object = form.save()

            if modelgsprequests.is_valid():
                modelgsprequests.instance = self.object
                modelgsprequests.save()

        return super(ModelGSPRequestUpdate).form_valid(form)


def create_model_gsp_request_form(request,id=None):
    print("Inside create_model_gsp_request_form")
    template_name = "ModelGSPRequest.html"
    heading_message = "ModelGSPRequest"

    if id:
        action = 'edit'
        model = get_object_or_404(ModelGSPRequest, pk=id)
    else:
        action = 'submit'
        model = ModelGSPRequest()

    message = ""

    if request.method == 'GET':
        print("Get request in create_model_gsp_request_form")
        # we don't want to display the already saved model instances
        #formset = ModelGSPRequestFormSet(queryset=ModelGSPRequest.objects.none(),instance=model)
        formset = ModelGSPRequestFormSet()
        registered_model_details = serializers.serialize("json", ModelRegister.objects.all())
        print("registered_model_details during GET Request in ModelGSPRequestForm:", registered_model_details)
    elif request.method == 'POST':
        print("post request in create_model_gsp_request_form")
        #formset = ModelGSPRequestFormSet(request.POST,request.FILES)
        formset = ModelGSPRequestFormSet(request.POST)
        registered_modelname = request.POST.get('registered_model')
        print("registered_modelname:", registered_modelname)
        print("before formset valid condition check")
        if formset.is_valid():
            print("If formset is valid")
            for form in formset:
                # only save if name is present
                if form.cleaned_data.get('registered_model'):
                    registered_model_no = form.cleaned_data['registered_model_no']
                    print("registered_model_no",registered_model_no)
                    new_form = form.save(commit=False)
                    new_form.model_gsp_requester = request.user.username
                    new_form.save()
                    formset.save_m2m()
            #return redirect('ModelGSPRequestList')
            return HttpResponseRedirect('/gspapp/ModelGSPRequestList')
    return render(request, template_name, {
            'formset': formset,
            'heading': heading_message,
            #'registered_model_data': registered_model_details,
            'action':action
        })


class ModelGSPRequestList(ListView):
    model = ModelGSPRequest
    template_name = "ModelGSPRequestList.html"
    context_object_name = "model_gsp_requests"
    paginate_by = 8
    form_class = ModelGSPRequestSearchForm
    form = form_class()

    def get_queryset(self):
        """
            Returns the query set that will be used to retrieve the object that this view will display.
            By default, get_queryset returns the value of the queryset attribute if it is set otherwise it
            constructs a Queryset by calling the all() method on model attributes default manager.
            Get the list of applied GSP request details in list format for the requested filter.This must be an iterable and may be a queryset.
        """
        # self.Category = get_object_or_404(GSP, name=self.kwargs['Category'])

        print("Inside ApplyGSPList::getqueryset")

        model_gsp_list_queryset = ModelGSPRequest.objects.all().order_by('-pk')

        return model_gsp_list_queryset

    def get_context_data(self, **kwargs):
        """
        :param kwargs: Base implementation of this method requires that self.object attribute to be set by the view.

               Calls the base implementation to first to get a context.
            Generally ,get_context_data will merge the context data of all parent classes with those of current class.
            To preserve this behaviour in your own classes where we want to alter the context , we should be sure to call
            the context on the super class

        :return: Returns context data for displaying the list of objects.
              It returns a dictionary with the contents:
              .object : The object that this view is displaying (self.object)
              context_object_name : self.object will also be stored under the name returned by get_context_object_name(),
              which defaults to the lower cased version of the model name.
        """

        print("ModelGSPRequestList::getcontextdata")

        context = super(ModelGSPRequestList, self).get_context_data(**kwargs)
        context.update(**kwargs)

        context['form'] = ModelGSPRequestSearchForm(self.request.GET)
        searchq = ""

        for item in self.request.GET:
            print("ModelGSPRequestList::self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            print("key:", key)
            print("value:", value)

            if key == "page":
                continue

            searchq += "%s=%s&" % (key, value)
            print("searchq in ModelGSPRequestListView inside for loop:", searchq)

        print("searchq in ModelGSPRequestListView:", searchq)
        context['searchq'] = searchq
        return context

class ApplyGSPList(ListView):
    """
        :param request : A class based view which accepts ListView to display the applied gsp statistics from common sas.
        :return        : Returns the list of gsp apply requests for the applied filter
        :description   :A listview which displays list of googlesecuritypatch apply requests from different users from common SAS:7620
    """
    print("Inside ApplyGSPList:")
    model = ApplyGSP
    form_class = ApplyGSPSearchForm

    context_object_name = 'apply_gsp_requests'  # Template variable used to access the list of google security patches
    template_name = "ApplyGSPList.html"
    paginate_by = 8
    apply_gsp_requests = []
    form = form_class()


    def get_queryset(self):
        """
            Returns the query set that will be used to retrieve the object that this view will display.
            By default, get_queryset returns the value of the queryset attribute if it is set otherwise it
            constructs a Queryset by calling the all() method on model attributes default manager.
            Get the list of applied GSP request details in list format for the requested filter.This must be an iterable and may be a queryset.
        """
        # self.Category = get_object_or_404(GSP, name=self.kwargs['Category'])

        print("Inside ApplyGSPList::getqueryset")

        apply_gsp_list_queryset = ApplyGSP.objects.all().order_by('-pk')

        for item in self.request.GET:
            key = item
            value = self.request.GET.get(item)

            if key == "ApplyGSP_User" and value:
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(user__icontains=value)

            if key == "ApplyGSP_model_name" and value:
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(model_name__icontains=value)

            if key == "ApplyGSP_model_no" and value:
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(model_no__exact=value)

            if key == "ApplyGSP_chipset" and value:
                chipset_name_to_search = Chipset.objects.get(id=value)
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(chipset__chipset_name__icontains=chipset_name_to_search)

            if key == "ApplyGSP_rel_cycle" and value:
                rel_cycle_to_search = ReleaseCycle.objects.get(id=value)
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(rel_cycle__release_cycle__icontains=rel_cycle_to_search)

            if key == "ApplyGSP_from_sas_url" and value:
                from_sas_url_to_search = SourceSASURL.objects.get(id=value)
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(from_sas_url__source_sas_url__icontains=from_sas_url_to_search)

            if key == "ApplyGSP_to_sas_url" and value:
                apply_gsp_list_queryset = apply_gsp_list_queryset.filter(to_sas_url__icontains=value)

        print("gsp_list_queryset:", apply_gsp_list_queryset)
        print("count of gsp_list_queryset:", apply_gsp_list_queryset.count())

        return apply_gsp_list_queryset

    def get_context_data(self, **kwargs):
        """
        :param kwargs: Base implementation of this method requires that self.object attribute to be set by the view.

               Calls the base implementation to first to get a context.
            Generally ,get_context_data will merge the context data of all parent classes with those of current class.
            To preserve this behaviour in your own classes where we want to alter the context , we should be sure to call
            the context on the super class

        :return: Returns context data for displaying the list of objects.
              It returns a dictionary with the contents:
              .object : The object that this view is displaying (self.object)
              context_object_name : self.object will also be stored under the name returned by get_context_object_name(),
              which defaults to the lower cased version of the model name.
        """

        print("ApplyGSPList::getcontextdata")

        context = super(ApplyGSPList, self).get_context_data(**kwargs)
        context.update(**kwargs)

        context['form'] = ApplyGSPSearchForm(self.request.GET)
        searchq = ""

        for item in self.request.GET:
            print("ApplyGSPList::self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            print("key:", key)
            print("value:", value)

            if key == "page":
                continue

            searchq += "%s=%s&" % (key, value)
            print("searchq in ApplyListView inside for loop:", searchq)

        print("searchq in ApplyListView:", searchq)
        context['searchq'] = searchq
        return context


def download_filtered_gsp_patches(request, id):
    """
    :param request: A function based view which accepts the http request when the user clicks on button to download the excel file.
    :param id: primary key for the User requested gsp filtered record
    :return: return the http response with the requested excel sheet using Content-Disposition header
    """
    print("click on excel download filtered GSP")
    # Get the excel file name of user requested GSP filtered request
    download_requested_excel_info = GSPECModel.objects.get(pk=id)
    filename = download_requested_excel_info.excelFile.name

    print("Tell browser to treat response as file attachment using content type arg and disposition:%s", filename)

    # To tell the browser to treat the response as a file attachment, use content_type argument
    # & set the Content-Disposition Header.
    response = HttpResponse(filename, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    print("Attach Content Disposition attachment")

    # Content-Disposition response is a header indicating if content is expected to be displayed inline in the browser.
    response['Content-Disposition'] = 'attachment;filename="%s"' %filename

    return response


def gspreview():
    pass