#from django.conf.urls import url
from django.urls import path, re_path, include
from . import views,ajax
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.views.static import serve
from rest_framework import routers


app_name = 'gspapp'

# django rest framework provides automatic url routing to django, providing you a simple,quick & consistent way of wiring
# your view logic to a set of URL's
# For more details: https://www.django-rest-framework.org/api-guide/routers/

#router = routers.DefaultRouter()
#router.register(r'ModelGSPRequest', views.ModelGSPRequestApi, basename='ModelGSPRequest')

urlpatterns = [
    path('GSPDCList/', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='GSPDCList'),
    path('', login_required(views.logon_view, login_url='/gspapp/login/'), name='GSPTracker'),
    path('login/', views.login_view, name='login'),
    # path('GSPDCList/', views.GSPDCList.as_view(), name='GSPDCList'),
    # re_path(r'^GSPDCList/(?:page-(?P<page_number>\d+)/)?$', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='editGSP'),
    re_path(r'^editGSP/(?P<id>\d+)/$', views.addgsp, name='editGSP'),
    path('AddGSP/', views.addgsp, name='AddGSP'),
    path('GSPExtract/', views.gsp_extract, name='GSPExtractFilter'),
    path('GSPECList/', login_required(views.GSPECList.as_view(), login_url='/gspapp/login/'), name='GSPECList'),
    re_path(r'^download/(?P<id>\d+)/$', views.download_filtered_gsp_patches, name='GSPExtractFilter'),

    path('ModelRegisterList/', login_required(views.ModelRegisterList.as_view(),login_url= '/gspapp/login/'), name='ModelRegisterList'),
    path('ModelRegister/requestForm/', views.model_register_form, name='ModelRegisterForm'),
    re_path(r'^editModelRegister/(?P<id>\d+)/$', views.model_register_form, name='editModelRegister'),

    path('ModelGSPRequestList/', login_required(views.ModelGSPRequestList.as_view(), login_url='/gspapp/login/'), name='ModelGSPRequestList'),
    #path('ModelGSPRequestList/requestForm/', login_required(views.ModelGSPRequestCreate.as_view(), login_url='/gspapp/login/'), name='ModelGSPRequestForm'),
    #re_path(r'^editModelGSPRequest/(?P<id>\d+)/$', login_required(views.ModelGSPRequestUpdate.as_view(), login_url='/gspapp/login/'), name='editModelGSPRequest'),

    path('ModelGSPRequestList/requestForm/', views.create_model_gsp_request_form, name='ModelGSPRequestForm'),
    re_path(r'^editModelGSPRequest/(?P<id>\d+)/$', views.create_model_gsp_request_form, name='editModelGSPRequest'),
    #path('',include(router.urls)),
    path('ModelGSPRequestList/requestForm/load_model_details/', ajax.load_model_details,name='load_model_details'),
    path('ModelGSPRequestList/requestForm/load_os_details/', ajax.load_os_details,name='load_os_details'),

    path('ApplyGSPList/', login_required(views.ApplyGSPList.as_view(), login_url='/gspapp/login/'), name='ApplyGSPList'),
    path('ApplyGSPList/requestForm/', views.apply_gsp_request_form, name='ApplyGSPRequestForm'),
    re_path(r'^editApplyGSP/(?P<id>\d+)/$', views.apply_gsp_request_form, name='editApplyGSP'),
    path('GSPReview/', views.gspreview, name='GSPReview'),
]

"""
if settings.DEBUG:
    urlpatterns += [
        re_path(r'^media/(?P<path>.*)$', serve, {
            'document_root': settings.MEDIA_ROOT,
        }),
    ]

"""
"""
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root = settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
"""
