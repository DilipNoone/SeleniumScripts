"""
    Tasks we write probably live in re-usable applications and reusable apps can't dependent on the
    project itself . We can't import application instance directly.
    To Send Email refer:https://docs.djangoproject.com/en/1.7/topics/email/#django.core.mail.EmailMessage
    For Pivotal Table: https://datatofish.com/count-duplicates-pandas/
                       https://www.geeksforgeeks.org/python-pandas-dataframe-count/

"""

from gspaat.celery import app
#from datetime import datetime
import datetime
from celery.decorators import task
#from datetime import timedelta
from openpyxl import Workbook
import os
from django.conf import settings
from django.http import HttpResponse
from django.core.files import File
import pandas as pd
from pandas import DataFrame
from tabulate import tabulate
from django.core.mail import EmailMultiAlternatives
from django.core.mail import EmailMessage
from django.template import loader, Context
from .models import GSP, GSPECModel

from celery.utils.log import get_task_logger
logger = get_task_logger(__name__)

# from celery import Celery
# app = Celery('tasks', broker='amqp://guest@localhost//')
# @app.task


@app.task(name="excelextract_sendmail")
def excelextract_sendmail(extract_filter_list, gsp_filter_records_id_list):

    """
    :param url_query_string: Receive url query parameter to process the filtered GSP records in background task
    :param extract_filter_list: Instance created to GSPECModel() to take the back up of filtered records.
    :param gsp_filter_records_id_list: This is a queryset in which user filtered google security patches are present.
    :return:
    """
    print("Inside excelextract_sendmail background task")
    extract_filter_list_record = GSPECModel.objects.get(pk=extract_filter_list)
    gsp_filtered_records_list = GSP.objects.filter(pk__in=gsp_filter_records_id_list)

    print("Extract filtered record id:", extract_filter_list_record.pk)

    print("GSP filtered records list", gsp_filtered_records_list)

    excel_name = 'GSP_Domain_Confirmation_Records_List_' + str(
        datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")) + '.xlsx'

    # excel_name = 'GSP_Domain_Confirmation_Records_List_' + str(
    #    datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")) + '.xlsx'

    # Update/Export the google security patches filtered records in to excel sheet
    workbook = update_gsp_filtered_records(gsp_filtered_records_list)
    workbook.save(excel_name)

    # Creating Pivotal Table for gsp filtered records
    gsp_pivoted_table, gsp_pending_notification = create_pivotal_table(excel_name)

    print("gsp_pivoted_table:", gsp_pivoted_table)
    print("gsp_pending_notification", gsp_pending_notification)

    # f = open(excel_name, "rb")
    f = open(excel_name, "rb", buffering=0)
    extract_filter_list_record.excelFile.save(excel_name, File(f))
    f.close()

    extract_filter_list_record.created_info = True
    extract_filter_list_record.save()

    try:
        os.remove(excel_name)
        print("%s removed Successfully")
    except OSError as error:
        print("Error:", error)
        print("File path can't be removed")

    # To send Email load template and render with the required data
    # gsp_pivotal_table_data_frame = gsp_pivoted_table.to_html(classes=False)
    # gsp_pending_notification_data_frame = gsp_pending_notification.to_html(classes=False)

    html_template_content = loader.get_template('email.html')
    plain_text_content = loader.get_template('email.txt')

    context = {
            'gsp_pivotal_table_df': gsp_pivoted_table,
            'gsp_count': extract_filter_list_record.gsp_count,
            'gsp_pending_notification_df': gsp_pending_notification,
    }

    html_content = html_template_content.render(context)
    text_content = plain_text_content.render(context)

    # From & To fields are defined to Send Email-Notification about Domain Ownership confirmation for GSP
    # To field should be changed to respective domain alias further

    from_email = 'extract_filter_list_record.user'
    to = 'sajalagarwal@example.com'
    body = '[GSP_Tracker] GSP Tracker Domain Confirmation Email Message Notification Failure'

    try:
        print("To send email using EmailMultiAlternatives")
        subject = '[GSP_Tracker] GSP Domain Confirmation Notification'

        # SettingUp Email to send both text and HTML Versions of a message
        email_msg = EmailMultiAlternatives(subject, text_content, from_email, [to], reply_to=['lgsi-IT1-team@lge.com'])
        email_msg.attach_alternative(html_content, "text/html")

        filename_to_attach = settings.MEDIA_ROOT + '/' + excel_name

        print("FileName", filename_to_attach)

        fd = open(filename_to_attach, errors='ignore')

        # Attach excel file to email message
        email_msg.attach(excel_name, fd.read(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        email_msg.send()

    except:
        subject = '[GSP_Tracker] GSP Domain Confirmation Failure Delivery Notification'
        email_msg = EmailMessage(subject, body, from_email, [to], reply_to=['lgsi-IT1-team@lge.com'])
        email_msg.send()

        return "Email not sent Successfully"
    print("Email Send Successfully")


def update_gsp_filtered_records(gsp_filtered_records_list):
    """
    Description: Update the gsp filtered records in to excel data
    :param gsp_filtered_records_list: queryset for gsp filtered records
    :return: workbook with updated filtered data records into rows and columns.
    """

    print("Calling update_gsp_filtered_records method")

    # Define the titles for the columns.
    columns = [
        'SerialNo',
        'RecordId',
        'Category',
        'SecurityPatchLevel',
        'Applicability',
        'Description',
        'GSP_ID',
        'HQDomainOwners',
        'LGSIDomainOwners',
        'OwnerShipStatus'
    ]

    print("Create the workbook instance to export the filtered record data into excel")
    workbook = Workbook()

    worksheet = workbook.active
    worksheet.title = 'GoogleSecurityPatches'

    # Define row number
    row_num = 1

    print("Assign the titles for each cell of the header:")

    # Assign the titles for each cell of the header.
    for col_num, column_title in enumerate(columns, 1):
        cell = worksheet.cell(row=row_num, column=col_num)
        print("cell", cell)
        print("column_title:", column_title)
        cell.value = column_title
        print("cell value:", cell.value)

    print("Iterate through all Google security Patches:")

    # Iterate through all the Google Security Patches.
    for gsp in gsp_filtered_records_list:
        row_num += 1
        lgsi_domainowner_list = [domain.LGSI_Domain_Owner_name for domain in gsp.LGSIDomainOwners.all()]
        hq_domainowner_list = [domain.HQ_Domain_Owner_name for domain in gsp.HQDomainOwners.all()]

        # Define the row data for each cell in the row.
        row = [
            row_num-1,
            gsp.pk,
            gsp.Category.category,
            gsp.SecurityPatchLevel.security_patch_level,
            gsp.Applicability,
            gsp.Description,
            gsp.GSP_ID,
            ",".join(hq_domainowner_list),
            ",".join(lgsi_domainowner_list),
            gsp.OwnersShipStatus,
        ]

        print("row data:", row)
        print("row_num:", row_num)

        # Assign the data for each cell of the row.
        for col_num, cell_value in enumerate(row, 1):
            print("row_num, col_num", row_num, col_num)
            cell = worksheet.cell(row=row_num, column=col_num)
            cell.value = cell_value
    return workbook


def create_pivotal_table(excel_name):
    """
    :param excel_name: create a pivotal table to send the domain confirmation pending for google security patches.
    :return: returns data frame created for pivotal table and gsp pending notification to domains
    """
    print("Inside create pivotal table")

    # read the specific columns from an excel file.
    require_cols = ['ID', 'Category', 'PatchLeve1', 'HQ Domain Owners', 'LGSIDomainOwners', 'Ownershipstatus']

    # only read the specific columns from an excel file.
    df = pd.read_excel(excel_name, use_cols=require_cols)
    df1 = df
    print("created data frame for GSP filtered records excel data:", df)

    # Creating data frame for the pivotal table with list of LGSI_Domain_Owners and count of each google security patch.
    gsp_pivoted_table = df.pivot_table(index=['LGSIDomainOwners'], aggfunc=['size'])
    gsp_pivoted_table.columns = ['DomainCount']

    print("Calling GSP Pivotal table before tabulation:", gsp_pivoted_table)
    gsp_pivoted_table = tabulate(gsp_pivoted_table, headers=('LGSIDomainOwners', 'DomainCount'), tablefmt='psql')
    print(gsp_pivoted_table)

    print("Calling GSP Pivotal table after tabulation:", gsp_pivoted_table)

    print("GSP Pending Status notification table with current ownership status")
    # To notify the GSP Pending notification for domain owners with current OwnerShipStatus
    gsp_pending_notification = pd.DataFrame(df1, columns=['LGSIDomainOwners', 'Ownershipstatus'])
    print(gsp_pending_notification)

    gsp_pending_notification["Ownershipstatus"].fillna("Domain Confirmation Pending", inplace=True)

    print("GSP Pending Notification table after replacing Nan Values with NotReviewed")

    gsp_pending_notification = tabulate(gsp_pending_notification,
                                        headers=('S.No', 'LGSIDomainOwners', 'OwnerShipStatus'), tablefmt='psql')

    return gsp_pivoted_table, gsp_pending_notification;