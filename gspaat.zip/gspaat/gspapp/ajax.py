from django.shortcuts import render_to_response,render
from django.http import Http404,HttpResponse
from .models import GSP,ModelRegister,ModelGSPRequest
import json

'''
def getGSPModel(request):
    print(request.get.GET)

    if request.is_ajax() and request.GET:
        print("is_ajax:", request.is_ajax())
        print("request.GET:", request.GET)
		
        gsp_model_id = request.GET.get("model", "")

        try:
            model = GSP.objects.get(pk=gsp_model_id)
            return render_to_response("gspapp/GSPListDisplay.html", {'model': model})
            #return GSP.objects.get(pk=(int)gsp_model_id)
        exception Exception:
            raise Http404
'''
'''
def load_model_details(request):
    print("load model details")
    print("request method",request.method,request.is_ajax())

    modelname = request.GET.get("model")
    print("modename in load_model_details:",modelname)

    model_registered_instances = ModelRegister.objects.filter(model_name=modelname).values_list('model_no',flat=True).distinct()
    print("model_registered_instances:",model_registered_instances)
    return render(request, 'model_info_options.html', {'model_registered_instances':model_registered_instances})
'''
def load_model_details(request):
    print("load model details")
    print("request method",request.method,request.is_ajax())
    context = {}

    modelname = request.GET.get("model")
    print("modename in load_model_details:",modelname)

    context["modelnos_for_model"] = list(ModelRegister.objects.filter(model_name=modelname).values_list('model_no',flat=True).order_by('model_no').distinct())
    print("context in load_model_details:",context)

    list_of_model_nos = context["modelnos_for_model"]

    print("list of model nos for selected model are:", list_of_model_nos)

    string_list_of_model_nos = [ str(modelnumber) for modelnumber in list_of_model_nos ]

    for modelno in range(len(string_list_of_model_nos)):
        print("type:",type(string_list_of_model_nos[modelno]))

    #context["modelnos_for_model"] = string_list_of_model_nos

    #print("context[modelnos_for_model]:",context["modelnos_for_model"]  )

    #return HttpResponse(json.dumps(context),content_type="application/json")

    return render(request, 'model_info_options.html', {'string_list_of_model_nos': string_list_of_model_nos})

def load_os_details(request):
    print("load os details")
    print("request method",request.method,request.is_ajax())

    modelnumbers = request.GET.getlist("model_nos[]")
    print("model numbers in load_os_details",modelnumbers)

    os_details_for_modelnumbers = ModelRegister.objects.filter(model_name='G5').values_list('os_name',flat=True).distinct()
    print("os_details_for_modelnumbers",os_details_for_modelnumbers)

    return render(request, 'model_os_details.html', {'os_details_for_modelnumbers':os_details_for_modelnumbers})




