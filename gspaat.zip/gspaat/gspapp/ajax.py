from django.models import GSP
from django.shortcuts import render_to_response
from django.http import Http404

def getGSPModel(request):
     if request.is_ajax() and request.GET:
         gsp_id = GSP.request.GET(model ,"")
         print("gsp_id:",gsp_id)
     try:
         model = GSP.objects.get(pk=(int)gsp_id)
         return render_to_response('gspapp/GSPListDisplay', {model:'Model'})
     exception:
         return Http404
