from django.apps import AppConfig


class GspappConfig(AppConfig):
    name = 'gspapp'
