#from django.conf.urls import url
from django.urls import include, path, re_path
from . import views
from gspapp.views import GSPDCList
from django.contrib.auth.decorators import login_required

app_name = 'gspapp'

#extra_patterns = [
#    path('login/', views.login_view, name='login')
#]


urlpatterns = [
    path('GSPDCList/', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='GSPDCList'),
    path('', login_required(views.logon_view, login_url='/gspapp/login/'), name='GSPTracker'),
    path('login/', views.login_view, name='login'),
    #path('GSPDCList/', views.GSPDCList.as_view(), name='GSPDCList'),
    #url(r'^editmodel/(?P<id>\d+)/$', views.Model_add_view,name='ModelEdit'),
    re_path('GSPDCList/(<?:page-(?P<page_number>\d+)/)?$', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='editGSP'),
    re_path('editGSP/(?P<id>\d+)/$', views.addgsp, name='editGSP'),
    path('AddGSP/', views.addgsp, name='AddGSP'),
    path('GSPECList/', views.gspeclist_view, name='GSPECList'),
    path('ApplyGSP/', views.applygsp_view, name='ApplyGSP'),
    path('GSPReview/', views.gspreview_view, name='GSPReview'),

]


'''
urlpatterns = [
    re_path(r'^/$', login_required(views.logon_view, login_url='/gspapp/login/'), name='GSPTracker'),
    re_path(r'^login/$', views.login_view, name='login'),
    re_path(r'^GSPDCList/$', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='GSPDCList'),
    re_path(r'^GSPDCList/(<?:page-(?P<page_number>\d+)/)?$', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='editGSP'),
    re_path(r'^viewGSP/<int:pk>/$', views.view_gsp, name='viewGSP'),
    re_path(r'^AddGSP/$', views.addgsp, name='AddGSP'),
]
'''