from django.shortcuts import Http404,HttpResponse,render_to_response
from .models import GSP


def getGSPModel(request):
    print(request.get.GET)

    if request.is_ajax() and request.GET:
        print("is_ajax:", request.is_ajax())
        print("request.GET:", request.GET)
		
        gsp_model_id = request.GET.get("model", "")

        try:
            model = GSP.objects.get(pk=(int)gsp_model_id)
            return render_to_response("gspapp/GSPDisplayList.html", {'model': model})
            return GSP.objects.get(pk=(int)gsp_model_id)
        exception Exception:
            raise Http404


