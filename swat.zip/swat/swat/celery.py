"""
Create a new Django Project celery.py module that defines the Celery instance.
For more information on this file:
http://docs.celeryproject.org/en/latest/django/first-steps-with-django.html#using-celery-with-django
"""

# First we import absolute imports from the future so that celery.py won't clash with the library.
from __future__ import absolute_import, unicode_literals
import os
from celery import Celery
from django.conf import settings
from django.db import connection

# Set the default DJANGO_SETTINGS_MODULE environmental variable for the command-line program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'swat.settings')

# You don't need this line , but it saves you from always passing in the setting module to the celery program.
# This is our instance of the library where we can have many instances.
app = Celery('swat')
# app = Celery(broker=settings.CELERY_BROKER_URL)


# We can also add Django Settings Module as a configuration source for Celery.

# This means we don't have to use Multiple Configuration files, and instead configure Celery directly
# from the Django settings;

# Using a string here means the worker does not have to serialize the configuration object to child processes.
# namespace = "CELERY" means all celery related configuration keys should have 'CELERY_' Prefix.
#app.config_from_object('django.conf:settings')
app.config_from_object('django.conf:settings', namespace='CELERY')

# For Versions <4, You don't need namespace hence commented.
# app.config_from_object('django.config:settings', namespace='CELERY')

# Load the task modules from all registered Django app configs.
app.autodiscover_tasks(settings.INSTALLED_APPS)

# With the line above Celery will automatically discover tasks from all of your installed apps

# Finally, the debug_task example is a task that dumps its own request information.
# This is using new bind = True task option introduced in Celery 1.3 to easily refer to the current task instance.


@app.task(bind=True)
def debug_task(self):
    print('Request.{0!r}'.format(self.request))
    print("connection schema", connection.schema_name)












