"""
Importing the django celery configured app from SWAT Project celery module.
This ensures that the app is loaded when the django starts so that the shared task decorator will use it.
"""

from __future__ import absolute_import, unicode_literals

# This will make sure that the app is always imported when Django starts so that shared_task will use this application.
from .celery import app as celery_app
__all__ = ('celery_app',)
