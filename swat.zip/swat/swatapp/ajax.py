########################################################################################################################

"""
    This file is used to load the model details when ajax request occurs in a form.
"""

########################################################################################################################

from .models import ModelRegister
from django.http import HttpResponse
from django.shortcuts import render
import json
from django.core import serializers


def load_model_details(request):
    """
        :param request: Accept http request
        :return:
    """

    print("load model details when we get Ajax request", request.method)
    print("Request is Ajax", request.is_ajax)
    requested_model_name = request.GET.get('selected_model')

    # Get the distinct model names for the selected model.

    instances_for_sel_model = []

    get_model_info_from_model_name = \
        ModelRegister.objects.filter(model_name=requested_model_name).values_list('model_no', flat=True).order_by('model_no').distinct()
    #get_model_info_from_model_name = ModelRegister.objects.filter(model_name=requested_model_name).order_by('model_no').distinct()
    #serialized_get_model_info_from_model_name = serializers.serialize('json', get_model_info_from_model_name)

    #print("serialized get_model_info_from_model_name:", serialized_get_model_info_from_model_name)

    #for selectedmodelinstance in serialized_get_model_info_from_model_name:
    #    instances_for_sel_model.append({'selectedmodelinstance': selectedmodelinstance})

    #print("instances_for_sel_model",instances_for_sel_model)

    print("get_model_info_from_model_name", get_model_info_from_model_name)
    context = {'get_model_info_from_model_name': get_model_info_from_model_name}
    return render(request, 'get_model_info_details.html', context)
    #return HttpResponse(json.dumps(serialized_get_model_info_from_model_name))ModelRegister.objects.filter(model_name=requested_model_name).values_list('model_no', flat=True).order_by('model_no').distinct()

