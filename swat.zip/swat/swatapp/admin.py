#########################################################################################################
"""
The ModelAdmin class is the representation of a model in the admin interface.
Usually these are stored in a file named admin.py in our Application.
"""
########################################################################################################

from django.contrib import admin
from .models import ReleaseType, OSName, ChipsetType, ChipsetName, SelectRegion, ReleaseCategory
from .models import SelectEvent, KeyIssueAction, ModelRegister


class ReleaseTypeAdmin(admin.ModelAdmin):
    pass


admin.site.register(ReleaseType)


class OSNameAdmin(admin.ModelAdmin):
    pass


admin.site.register(OSName)


class ChipsetTypeAdmin(admin.ModelAdmin):
    pass


admin.site.register(ChipsetType)


class ChipsetNameAdmin(admin.ModelAdmin):
    pass


admin.site.register(ChipsetName)


class SelectRegionAdmin(admin.ModelAdmin):
    pass


admin.site.register(SelectRegion)


class ReleaseCategoryAdmin(admin.ModelAdmin):
    pass


admin.site.register(ReleaseCategory)


class SelectEventAdmin(admin.ModelAdmin):
    pass


admin.site.register(SelectEvent)


class KeyIssueActionAdmin(admin.ModelAdmin):
    pass


admin.site.register(KeyIssueAction)


#class KeyIssueCommentOptionSelectionAdmin(admin.ModelAdmin):
#    pass


#admin.site.register(KeyIssueCommentOptionSelection)


class ModelRegisterAdmin(admin.ModelAdmin):
    pass


admin.site.register(ModelRegister)

'''
class ConcludeKeyIssuesAdmin(admin.ModelAdmin):
    pass


admin.site.Register(ConcludeKeyIssues)
'''