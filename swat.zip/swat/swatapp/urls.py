########################################################################################################################
"""
    This file is used to design the URL for an application provides mapping between URL path expressions
    to Python functions.

    Django Version:3.0
    Python Version:3.6.2

    For more information on this file:
    ----------------------------------

    =================================================================================================
    For URL info:  https://docs.djangoproject.com/en/3.0/topics/http/urls
    =================================================================================================

"""
#######################################################################################################################

from django.urls import path, re_path
from . import ajax
from . import views

from django.contrib.auth.decorators import login_required

app_name = 'swatapp'

urlpatterns = [
    path('Dashboard/', login_required(views.logon_dashboard_view, login_url='/swatapp/login/'), name='dashboard'),
    path('ajax/ConcludeKeyIssue/requestForm/load_model_details', ajax.load_model_details, name='load_model_details'),

    path('login/', views.user_login_view, name='login'),
    path('login/', views.user_logout, name='logout'),

    path('ModelRegisterList/', login_required(views.ModelRegisterList.as_view(), login_url='/swatapp/login/'),
         name='ModelRegisterList'),
    path('ModelRegister/requestForm/', views.model_register_form, name='ModelRegisterForm'),
    re_path(r'^editModelRegister/(?P<id>\d+)/$', views.model_register_form, name='editModelRegister'),

    path('ConcludeKeyIssueList/', login_required(views.ConcludeKeyIssueList.as_view(), login_url='/swatapp/login/'),
         name='ConcludeKeyIssueList'),
    path('ConcludeKeyIssue/requestForm/', views.conclude_key_issue_form, name='ConcludeKeyIssueForm'),
    re_path(r'^editConcludeKeyIssue/(?P<id>\d+)/$', views.conclude_key_issue_form, name='editConcludeKeyIssue'),

]
