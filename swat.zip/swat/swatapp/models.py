#############################################################################################################
"""
    This file is used to create the Model, where each model maps to a single data base table.

    Django Version:3.0
    Python Version:3.6.2

    For more information on this file:
    ----------------------------------

    =================================================================================================
    For model info:  https://docs.djangoproject.com/en/3.0/topics/db/models
    For field types: https://docs.djangoproject.com/en/3.0/ref/forms/fields/#django.forms.FloatField
    =================================================================================================
"""
#############################################################################################################

from __future__ import unicode_literals
from django.db import models
from django.utils import timezone

# Create your models here.


class SelectRegion(models.Model):
    """
        This class is used to select the region
    """
    region = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.region

    class Meta:
        verbose_name_plural = "Regions"


class SelectEvent(models.Model):
    """
        This class is used to select the event for Key Issue Comment.
    """

    event_name = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.event_name

    class Meta:
        verbose_name_plural = "SelectEvents"


class ReleaseCategory(models.Model):
    """
        This class is used to select the release Category :[ QP/MR/SMR/eMR/CPL-MR ]
    """
    release_category = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.release_category

    class Meta:
        verbose_name_plural = "ReleaseCategories"


class ReleaseType(models.Model):
    """
        This class is used to choose the release Type : [Base,CA,OSU etc]
    """
    release_type = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.release_type

    class Meta:
        verbose_name_plural = "ReleaseTypes"


class OSName(models.Model):
    """
        This class is used to define the OS Name.[OS : NOS/OOS/POS etc ]
    """
    osname = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.osname

    class Meta:
        verbose_name_plural = "OSNames"


class ChipsetType(models.Model):
    """
        This class is used to define the chipset Type [ QCT/MTK ]
    """
    chipsettype = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.chipsettype

    class Meta:
        verbose_name_plural = "ChipsetTypes"


class ChipsetName(models.Model):
    """
        This class is used to define the chipset name for a specific model.
    """
    chipsetname = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.chipsetname

    class Meta:
        verbose_name_plural = "ChipsetNames"


class SelectChipsetType(models.Model):
    """
        This class is used to select the Chipset Type [QCT/MTK] for a specific model to conclude Key Issue.
    """

    select_chipset_type = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.select_chipset_type

    class Meta:
        verbose_name_plural = "SelectChipsetTypes"


class SelectChipsetName(models.Model):
    """
        This class is used to select the Chipset Name for a specific model to conclude Key Issue.
    """

    select_chipset_name = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.select_chipset_name

    class Meta:
        verbose_name_plural = "SelectChipsetNames"


class SelectOSName(models.Model):
    """
        This class is used to select the OSNames for a specific model to conclude Key Issue.
    """

    select_os_names = models.CharField(max_length=30, unique=True)

    def __str__(self):
        return self.select_os_names

    class Meta:
        verbose_name_plural = "SelectOSNames"


class KeyIssueAction(models.Model):
    """
        This class is used to choose the action to perform for a KeyIssue.
    """

    action = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.action

    class Meta:
        verbose_name_plural = "KeyIssueAction"

'''
class KeyIssueCommentOptionSelection(models.Model):
    """
        This class is used to choose the option for Key Issue Comment.
    """
    key_issue_comment_option = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.key_issue_comment_option

    class Meta:
        verbose_name_plural = "KeyIssueCommentOptionsSelection"
'''

class ModelNo(models.Model):
    """
        This class is used to have model numbers for selected model.
    """

    model_no = models.CharField(max_length=128, unique=True)

    def __str__(self):
        return self.model_no

    class Meta:
        verbose_name_plural = "ModelNos"


class ModelRegister(models.Model):
    """
        This class is used to register the model information.
    """
    FLOAT_CHOICES = [[float(x), float(x)] for x in range(1, 21)]
    user = models.CharField("User", max_length=128, blank=True)

    model_name = models.CharField(max_length=128, verbose_name="Model Name")
    model_no = models.CharField(max_length=128, verbose_name="Model No")
    os_name = models.ForeignKey(OSName, on_delete=models.CASCADE,
                                verbose_name="Select OS Name")
    os_version = models.FloatField(max_length=100, choices=FLOAT_CHOICES,
                                   verbose_name="Select OS Version",
                                   help_text="[Choose OS Version Ex:OOS:8.0, POS:9.0, QOS:10.0 etc]")
    chipset_type = models.ForeignKey(ChipsetType, on_delete=models.CASCADE, verbose_name="Chipset Type")
    chipset_name = models.ManyToManyField(ChipsetName, verbose_name="Chipset Name")

    class Meta:
        verbose_name_plural = "ModelRegistration"

    def __str__(self):
        return self.model_name


class ConcludeKeyIssues(models.Model):
    """
        This class is used to conclude the key issues for a specific model.
    """
    INTEGER_CHOICES = [(x, x) for x in range(1, 21)]
    integrator_id = models.CharField("User", max_length=128)
    integrator_pwd = models.CharField("Password", max_length=128)
    #registered_model = models.ForeignKey(ModelRegister, on_delete=models.CASCADE, default="")
    #model_name = models.CharField("Select Model", max_length=128, default="")
    registered_model = models.CharField("Select Model Name", max_length=128)
    registered_model_no = models.CharField("Select Model No", max_length=128,default="")

    #registered_model_no = models.ManyToManyField(ModelNo, verbose_name="Model Number")
    select_os_name = models.ForeignKey(OSName, on_delete=models.CASCADE, verbose_name="Select OS Name")
    select_chipset_type = models.ForeignKey(ChipsetType, on_delete=models.CASCADE, verbose_name="Select Chipset Type")
    select_chipset_name = models.ManyToManyField(ChipsetName, default="")
    #select_os_name = models.ManyToManyField(SelectOSName, verbose_name="Select OS Name", default="")
    #select_chipset_type = models.ManyToManyField(SelectChipsetType, verbose_name="Select Chipset Type", default="")
    #select_chipset_name = models.ManyToManyField(SelectChipsetName, verbose_name="Select Chipset Name", default="")

    rel_type = models.ForeignKey(ReleaseType, on_delete=models.CASCADE, verbose_name="Release Type")
    rel_category = models.ForeignKey(ReleaseCategory, on_delete=models.CASCADE, verbose_name="Release/Event Category")
    rel_cycle = models.IntegerField(choices=INTEGER_CHOICES, verbose_name="Release Cycle")

    Region = models.ForeignKey(SelectRegion, on_delete=models.CASCADE, verbose_name="Region")
    event_for_key_issue_comment = models.ForeignKey(SelectEvent, on_delete=models.CASCADE,
                                                    help_text="Choose Event for Key Issue Comment")
    Action = models.ForeignKey(KeyIssueAction, on_delete=models.CASCADE,
                               verbose_name="Key Issue Action")
    # sas_ids = models.CharField(max_length=200, verbose_name="Input SAS ID's separated by comma [ Ex:13799,14033 ]")
    sas_id = models.CharField("Input SAS BoardID Details",
                              max_length=128,
                              help_text="Input SAS ID's Separated by Comma:Ex:13799,14033")

    requested_time = models.DateTimeField(default=timezone.now)
    key_issue_count = models.IntegerField(blank=True, null=True)
    #key_issue_comment_option_selection = models.ForeignKey(
    #                                         KeyIssueCommentOptionSelection, on_delete=models.CASCADE,
    #                                         verbose_name="Key Issue Option Selection",
    #                                         help_text="Select Option for KeyIssueComment Default/Editable"
    #                                         )

    key_issue_comment = models.TextField()
    # description = models.TextField()

    class Meta:
        verbose_name_plural = "Conclude_Key_Issues"

    def __str__(self):
        return self.registered_model + str(self.pk)



