from django.apps import AppConfig


class SwatappConfig(AppConfig):
    name = 'swatapp'
