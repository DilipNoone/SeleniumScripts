########################################################################################################################
"""
    This file is used to define the form rendering behaviour.
    django-crispy-forms : Implements a class called FormHelper that defines form rendering behaviour.
    Helpers gives a way to control the form attributes and its lay out ,doing this in a programmatic way using python.
    This way you write as little HTML code as possible, & all your logic stays in the forms and view files.
            For more details refer: https://django-crispy-forms.readthedocs.io/en/d-0/index.html
                                    https://django-crispy-forms.readthedocs.io/en/latest/form_helper.html
                                    https://django-crispy-forms.readthedocs.io/en/latest/layouts.html
                            Submit: https://django-crispy-forms.readthedocs.io/en/d-0/layouts.html?highlight=submit
    choices:A sequence consisting itself of iterables of exactly two times to use as choices for this field.
            For more details refer: https://docs.djangoproject.com/en/3.0/ref/models/fields/

"""
########################################################################################################################

from django import forms
from django.forms import ModelForm
from django.contrib.auth.forms import AuthenticationForm
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Div, Submit, HTML, ButtonHolder, Button, Row, Column, Field, Fieldset, LayoutObject
from crispy_forms.bootstrap import FormActions
from .models import ChipsetName, ModelRegister, ConcludeKeyIssues, OSName, ChipsetType, ChipsetName
from .models import ReleaseCategory, SelectRegion
from django.core import validators
from django.core.exceptions import ValidationError
# from django.forms.widgets import CheckboxSelectMultiple
# from django.forms.models import ModelMultipleChoiceField


class LoginForm(AuthenticationForm):
    """
        This class is used to define the layout for Login Form using Django crispy form helper
    """
    remember_me = forms.BooleanField(required=True, initial=False)

    def __init__(self, *args, **kwargs):
        # username = forms.CharField(max_length=100)
        # password = forms.CharField(max_length=100)

        super(LoginForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_action = '.'
        self.helper.form_class = 'form-horizontal'
        # self.helper.label_class = "col-md-2"
        # self.helper.field_class = "col-md-8"
        '''
        self.helper.layout = Layout(
            Field('username', placeholder="Enter Your Username", autofocus=""),
            Field('password', placeholder="Enter Your Password"),
            Field('remember_me'),
            ButtonHolder(
                Submit('sign_in', 'Log in'),
            )
        )
        '''

        self.helper.layout = Layout(
            Fieldset('Log in with your AD account & Password',
                     Row('username', style="padding-left: 25em", css_class='large-8'),
                     Row('password', style="padding-left: 25em", css_class='large-8'),
                     Row('remember_me', style="padding-left: 25em", css_class='large-8'),
                     Submit('submit', 'Log in')
                     )
            )

'''
class CustomSelectMultiple(ModelMultipleChoiceField):
    def label_from_instance(self, obj):
        return "%s" % obj.chipsetname
'''


class ModelRegisterForm(ModelForm):
    """
        This class is used to create the form to register the model information.
        To define the same , field attribute is set to the special value __all__
    """

    # FLOAT_CHOICES = [[float(x), float(x)] for x in range(1, 21)]

    # os_version = forms.FloatField(label="Select OS Version [Ex: OOS:8.0, POS:9.0, QOS:10.0 etc]",
    #                              widget=forms.Select(choices=FLOAT_CHOICES))
    # chipset_name = CustomSelectMultiple(queryset=ChipsetName.objects.all())

    class Meta:
        model = ModelRegister
        fields = '__all__'
        # widgets = {"chipset_name": CheckboxSelectMultiple()}

    # @property
    def __init__(self, *args, **kwargs):
        super(ModelRegisterForm, self).__init__(*args, **kwargs)
        # self.fields["chipset_name"].widget = CheckboxSelectMultiple()
        # self.fields["chipset_name"].queryset = ChipsetName.objects.all()
        self.helper = FormHelper()
        self.helper.form_tag = 'model_register_form'
        self.helper.layout = Layout(
            Fieldset(
                        'Add Model Details',
                        Row(
                            Column('model_name', css_class='large-4'),
                            Column('model_no', style="padding-left: 3em", css_class='large-4'),
                        ),
                        Row(
                            Column('os_name', css_class='large-4'),
                            Column('os_version', style="padding-left: 3em", css_class='large-4'),

                        ),
                        Row(
                            Column('chipset_type', css_class='large-4'),
                            Column('chipset_name', style="padding-left: 3em", css_class='large-4')
                        )
                    )
        )


class ModelRegisterSearchForm(forms.Form):
    """
        This class is used to display the search form for registered Model.
    """
    ModelRegister_User = forms.CharField(label="Model Registered User", max_length=100, required=False)
    ModelRegister_model_name = forms.CharField(label="Registered Model Name", max_length=100, required=False)
    ModelRegister_model_no = forms.CharField(label="Registered Model No", max_length=100, required=False)
    ModelRegister_os_name = forms.ModelChoiceField(label="Registered Model OS Name", queryset=OSName.objects.all(),
                                                   empty_label="Select OS Name", required=False)
    ModelRegister_chipset_type = forms.ModelChoiceField(label="Registered Chipset Type",
                                                        queryset=ChipsetType.objects.all(),
                                                        empty_label="Select Chipset Type", required=False)
    ModelRegister_chipset_name = forms.ModelMultipleChoiceField(label="Registered Model Chipset",
                                                                queryset=ChipsetName.objects.all(),
                                                                required=False)

    class Meta:
        model = ModelRegister

    def __init__(self, *args, **kwargs):
        super(ModelRegisterSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'form-ModelRegisterSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-md-2"
        self.helper.field_class = "col-md-10"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False

        self.helper.layout = Layout(
            Field('ModelRegister_User', placeholder="Enter UserID"),
            Field('ModelRegister_model_name', placeholder="Enter ModelName"),
            Field('ModelRegister_model_no', placeholder="Enter ModelNo"),
            Field('ModelRegister_os_name', placeholder="Enter OS Name"),
            Field('ModelRegister_chipset_type', placeholder="Enter Chipset Type"),
            Field('ModelRegister_chipset_name', placeholder="Enter Chipset Name"),
        )


def unique_model_names():
    """
    :return:
    """
    return [("", "------")] + list(ModelRegister.objects.values_list('model_name', 'model_name').order_by('model_name').distinct())


class DynamicChoiceField(forms.ChoiceField):
    def valid_value(self, value):
        return True

class ConcludeKeyIssuesForm(ModelForm):
    """
        This class is used to define the form to Conclude Key Issues for a specific Model.
    """

    # INTEGER_CHOICES = [(x, x) for x in range(1, 21)]

    #  rel_cycle = forms.IntegerField(label="Select Release Cycle [Ex:If Cycle is VP1,Choose:1,Cycle is VP2:Choose:2]",
    #                               widget=forms.Select(choices=INTEGER_CHOICES))
    integrator_pwd = forms.CharField(label='Input Your Windows Password', widget=forms.PasswordInput())
    #registered_model = forms.ModelChoiceField(label="Select Model",
    #                                          queryset=ModelRegister.objects.all().values_list('model_name', flat=True).distinct())

    # chipset_name = CustomSelectMultiple(queryset=ChipsetName.objects.all())

    registered_model = forms.ChoiceField(required=False, choices=unique_model_names, widget=forms.Select)
    registered_model_no = forms.ChoiceField(required=False, widget=forms.SelectMultiple)

    class Meta:
        model = ConcludeKeyIssues
        exclude = ['integrator_id', 'requested_time', 'key_issue_count']
        # widgets = {"chipset_name": CheckboxSelectMultiple()}

    def clean_registered_model_no(self):
        print("clean_regsitered_modelno",','.join(self.cleaned_data['registered_model_no']))
        return ','.join(self.cleaned_data['registered_model_no'])

    '''      
    def clean(self):
        cleaned_data = super().clean()
        registered_model = self.cleaned_data.get('registered_model')
        #registered_model_nos = self.cleaned_data.get('registered_model_no')
        #registered_model_nos = ','.join(str(self.cleaned_data.get('registered_model_no')))
        registered_model_nos = cleaned_data['registered_model_no']
        print("clean Method:registered model", registered_model)
        print("clean Method :ModelGSPRequestForm:", registered_model_nos)
    '''

    '''
    def validate(self, value, model_instance):
        arr_choices = self.get_choices_selected(self.get_choices_default())
        for opt_select in value:
            if opt_select not in arr_choices:
                raise ValidationError(self.error_messages['invalid_choice'] % value)
        return

    def get_choices_selected(self, arr_choices=''):
        if not arr_choices:
            return False
        list = []
        for choice_selected in arr_choices:
            list.append(choice_selected[0])
        return list
    '''

    # @property
    def __init__(self, *args, **kwargs):

        super(ConcludeKeyIssuesForm, self).__init__(*args, **kwargs)
        #selected_model_name = kwargs.pop('registered_model_obj')
        #print("selected model name in key issue form constructor", selected_model_name)
        self.fields["key_issue_comment"].widget.attrs['style'] = 'width:1110px;height:100px'
        # self.fields["chipset_name"].queryset = ChipsetName.objects.all()
        self.helper = FormHelper()
        self.helper.form_tag = 'conclude_key_issue_form'
        self.helper.layout = Layout(
            Fieldset(
                'Select Your Model From Drop Down To Fill Model Details',
                Row(
                    Column('integrator_pwd', css_class='large-4'),
                    Column('registered_model', style="padding-left: 3em", css_class='large-4'),
                ),
                Row(
                    Column('registered_model_no', css_class='large-4'),
                    Column('select_os_name', style="padding-left: 3em", css_class='large-4'),
                    Column('select_chipset_type', style="padding-left: 3em", css_class='large-4'),
                    Column('select_chipset_name', style="padding-left: 3em", css_class='large-4'),
                ),

                Row(
                    Column('rel_type', css_class='large-4'),
                    Column('rel_category', style="padding-left: 3em", css_class='large-4'),
                    Column('rel_cycle', style="padding-left: 3em", css_class='large-4'),
                    Column('Region', style="padding-left: 3em", css_class='large-4'),
                ),
                Row(
                    Column('sas_id', css_class='large-4'),
                    Column('event_for_key_issue_comment', style="padding-left: 3em", css_class='large-4'),
                    Column('Action', style="padding-left: 3em", css_class='large-4'),
                    # Column('key_issue_comment_option_selection', style="padding-left: 3em", css_class='large-4'),
                ),

                FormActions(ButtonHolder(Button('Clear', 'clear', css_class='btn btn-secondary float-right'))),

                Row(
                    Column('key_issue_comment'),
                )
            )
        )

        # self.fields['registered_model'].choices = ModelRegister.objects.values_list('model_name','model_name').order_by('model_name').distinct()
        # self.fields['registered_model'].queryset =  ModelRegister.objects.values_list('model_name',flat=True).order_by('model_name').distinct()
        self.fields['registered_model_no'].queryset = ModelRegister.objects.none()
        #self.fields['registered_model_no'].queryset = ModelRegister.objects.filter(
        #            registered_model=selected_model_name).values_list('model_no', flat=True).order_by('model_no').distinct()

        if 'registered_model' in self.data:  # If there is some form post data
            # if self.is_bound:
            print("form post data")
            try:
                #registered_model_name = int(self.data.get('registered_model'))
                registered_model_name = str(self.data.get('registered_model'))
                print("registered_model_name:", registered_model_name)
                #self.fields['registered_model_no'].queryset = ModelRegister.objects.filter(model_name=registered_model_name).values_list('model_no', flat=True).order_by('model_no').distinct()
                self.fields['registered_model_no'].choices = [(x, x) for x in ModelRegister.objects.filter(model_name=registered_model_name).values_list('model_no', flat=True).order_by('model_no').distinct()]
                print("self.fields['registered_model_no'].choices", self.fields['registered_model_no'].choices)
            except (ValueError, TypeError):
                pass  # invalid input from the client ; ignore and use empty queryset
                print("invalid input from client")
        #elif self.instance.pk:
        #    print(" post data with pk")
        #    self.fields['registered_model_no'].queryset = self.instance.registered_model.registered_model_no_set.order_by(
        #        'registered_model_no')
        else:
            print("No post data")

        super(ConcludeKeyIssuesForm, self).full_clean()


class ConcludeKeyIssuesSearchForm(forms.Form):
    """
        This class is used to display the search form for the Key Issues applied for a specific model.
    """
    ConcludedKeyIssues_User = forms.CharField(label="Concluded Key Issue User", max_length=100, required=False)
    ConcludedKeyIssues_model_name = forms.CharField(label="ConcludedKeyIssue Model Name", max_length=100, required=False)
    ConcludedKeyIssues_model_no = forms.CharField(label="Concluded Key Issue Model No", max_length=100, required=False)
    ConcludeKeyIssues_os_name = forms.ModelChoiceField(label="Concluded Key Issue OS Name",
                                                       queryset=OSName.objects.all(),
                                                       empty_label="Select OS Name", required=False)
    ConcludeKeyIssues_chipset_type = forms.ModelChoiceField(label="Concluded Key Issue Chipset Type",
                                                            queryset=ChipsetType.objects.all(),
                                                            empty_label="Select Chipset Type", required=False)
    ConcludeKeyIssues_chipset_name = forms.ModelMultipleChoiceField(label="Concluded Key ISsue Name",
                                                                    queryset=ChipsetName.objects.all(),
                                                                    required=False)
    ConcludeKeyIssues_release_category = forms.ModelChoiceField(label="Concluded Key Issue Release Category",
                                                                queryset=ReleaseCategory.objects.all(),
                                                                required=False)
    ConcludeKeyIssues_region = forms.ModelChoiceField(label="Select Region",
                                                      queryset=SelectRegion.objects.all(),
                                                      required=False)

    class Meta:
        model = ConcludeKeyIssues

    def __init__(self, *args, **kwargs):
        super(ConcludeKeyIssuesSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.form_class = 'form-inline'
        self.helper.form_id = 'form-ConcludeKeyIssueSearchForm'
        self.helper.form_method = 'GET'
        self.helper.label_class = "row-sm-2"
        self.helper.field_class = "row-sm-4"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False

        self.helper.layout = Layout(
            Field('ConcludedKeyIssues_User', placeholder="Enter UserID"),
            Field('ConcludedKeyIssues_model_name', placeholder="Enter ModelName"),
            Field('ConcludedKeyIssues_model_no', placeholder="Enter ModelNo"),
            Field('ConcludeKeyIssues_os_name', placeholder="Enter OS Name"),
            Field('ConcludeKeyIssues_chipset_type', placeholder="Enter Chipset Type"),
            Field('ConcludeKeyIssues_chipset_name', placeholder="Enter Chipset Name")
        )



