###############################################################################################
"""
    This file is used to address the presentation logic of your application.
    For more details about custom template tags and filters:
    Refer : https://docs.djangoproject.com/en/3.0/howto/custom-template-tags/
"""
##############################################################################################

from django import template
register = template.Library()


@register.filter
def concat_str_number(value1, value2):
    return str(value1)+str(value2)

