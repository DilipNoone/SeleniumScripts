"""
    This file is used to run the Web based automation tasks through selenium.
    Reference document:https://selenium-python.readthedocs.io

"""

from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException, TimeoutException, UnexpectedAlertPresentException
from selenium.common.exceptions import StaleElementReferenceException, NoAlertPresentException, ElementClickInterceptedException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import os
import sys
import time
from .models import ConcludeKeyIssues
#from .tasks import send_gsp_dependency_request_details