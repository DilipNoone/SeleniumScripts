#from django.conf.urls import url
from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required

app_name = 'gspapp'

urlpatterns = [
    #url(r'^$', login_required(views.logon_view, login_url='/gspapp/login'), name='logon'),
    #url(r'^login/$', views.login_view, name='login'),
    #url(r'^addgsp/$', views.addgsp_view, name='AddGSP'),
    path('', login_required(views.logon_view, login_url='/gspapp/login'), name='GSPTracker'),
    path('GSPList/', login_required(views.gsplist_view, login_url='/gspapp/'), name='GSPList'),
    path('login/', views.login_view, name='login'),
    path('AddGSP/', views.addgsp_view, name='AddGSP'),
]
