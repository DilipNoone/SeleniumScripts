#from django.conf.urls import url
from django.urls import include, path
from . import views
#from .views import GSPDCList
from django.contrib.auth.decorators import login_required

app_name = 'gspapp'

#extra_patterns = [
#    path('login/', views.login_view, name='login')
#]

urlpatterns = [
    path('', login_required(views.logon_view, login_url='/gspapp/login/'), name='GSPTracker'),
    path('login/', views.login_view, name='login'),
    path('GSPDCList/', login_required(views.GSPDCList.as_view(), login_url='/gspapp/login/'), name='GSPDCList'),
    path('AddGSP/', views.addgsp, name='AddGSP'),
    #path('AddGSP/', include(extra_patterns)),
]
