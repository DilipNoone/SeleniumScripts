from django.contrib import admin
from .models import GSP,Category,LGSIDomainOwner,HQDomainOwner,GspOwnerShipStatus
# Register your models here.

"""
The ModelAdmin class is the representation of a model in the admin interface.
Usually these are stored in a file named admin.py in our Application.
"""


class GSPAdmin(admin.ModelAdmin):
    pass


" Register 'GSP' Model Class with a Model admin description"
admin.site.register(GSP, GSPAdmin)


class CategoryAdmin(admin.ModelAdmin):
    pass


admin.site.register(Category, CategoryAdmin)


class LGSIDomainOwnerAdmin(admin.ModelAdmin):
    pass


admin.site.register(LGSIDomainOwner, LGSIDomainOwnerAdmin)


class HQDomainOwnerAdmin(admin.ModelAdmin):
    pass


admin.site.register(HQDomainOwner, HQDomainOwnerAdmin)


class GspOwnerShipStatusAdmin(admin.ModelAdmin):
    pass


admin.site.register(GspOwnerShipStatus, GspOwnerShipStatusAdmin)