from django.contrib import admin
from .models import GSP
# Register your models here.


admin.site.register(GSP)


