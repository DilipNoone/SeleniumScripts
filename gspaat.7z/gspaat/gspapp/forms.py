from django import forms
from django.contrib.auth.forms import AuthenticationForm
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Div, Submit, HTML, ButtonHolder, Row, Field, LayoutObject
from django.forms import ModelForm
from .models import GSP


# from crispy_forms.bootstrap import InlineField
# from crispy_forms_foundation.settings import *
# from crispy_forms_foundation.layout import Layout,Fieldset,ButtonHolder

# from .models import BlogArticle

class LoginForm(AuthenticationForm):
    """
        This class is used to define the layout for Login Form using Django crispy form helper
    """
    remember_me = forms.BooleanField(required=True, initial=False)

    def __init__(self, *args, **kwargs):
        # username = forms.CharField(max_length=100)
        # password = forms.CharField(max_length=100)

        super(LoginForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_action = '.'
        self.helper.layout = Layout(
            Field('username', placeholder="Enter Username", autofocus=""),
            Field('password', placeholder="Enter Password"),
            Field('remember_me'),
            Submit('sign_in', 'Log in',
                   css_class="btn btn-lg btn-primary btn-block"),
        )


class GSPSearchForm(forms.Form):
    Applicability = forms.CharField(max_length=100)
    SecurityPatchlevel = forms.CharField(max_length=100)
    Description = forms.CharField(max_length=100)
    DomainOwner = forms.CharField(max_length=100)
    HQOwner = forms.CharField(max_length=100)

    def __init__(self, *args, **kwargs):
        super(GSPSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_class = 'form-inline'
        self.helper.label_class = ".col-lg-2"
        self.helper.field_class = ".col-lg-8"
        self.helper.layout = Layout(
            Field('Applicability', placeholder="Enter Applicability"),
            Field('SecurityPatchlevel', placeholder="Enter Security Patch level"),
            Field('Description', placeholder="Enter Description"),
            Field('DomainOwner', dropdown_menu="Enter DomainOwner"),
            Field('HQOwner', dropdown_menu="Enter HQOwner"),
        )


class AddGSPForm(ModelForm):
    """
        This class is used to add Google security patch for all the fields defined in Model
        To define the same , field attribute is set to the special value __all__
    """

    class Meta:
        model = GSP
        fields = '__all__'
