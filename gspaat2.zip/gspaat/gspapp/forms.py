from django import forms
from django.contrib.auth.forms import AuthenticationForm
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Div, Submit, HTML, ButtonHolder, Row, Field, LayoutObject
from django.forms import ModelForm
from .models import GSP, Category, LGSIDomainOwner, HQDomainOwner


# from crispy_forms.bootstrap import InlineField
# from crispy_forms_foundation.settings import *
# from crispy_forms_foundation.layout import Layout,Fieldset,ButtonHolder

# from .models import BlogArtic

class LoginForm(AuthenticationForm):
    """
        This class is used to define the layout for Login Form using Django crispy form helper
    """
    remember_me = forms.BooleanField(required=True, initial=False)

    def __init__(self, *args, **kwargs):
        # username = forms.CharField(max_length=100)
        # password = forms.CharField(max_length=100)

        super(LoginForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_action = '.'
        self.helper.layout = Layout(
            Field('username', placeholder="Enter Username", autofocus=""),
            Field('password', placeholder="Enter Password"),
            Field('remember_me'),
            Submit('sign_in', 'Log in',
                   css_class="btn btn-lg btn-primary btn-block"),
        )


class GSPSearchForm(forms.Form):
    """
        This form is used to display the search form containing GSP fields.
        ModelChoiceField : Default widget for ModelChoiceField becomes impractical when the number of entries more than
        100. It takes one single argument and optional two arguments.
        single arg Queryset: A queryset of GSPModel objects from which the choices of field are derived and this is used
        to validate users selection.Its evaluated when form is rendered.
        second arg:empty_label
        ModelMultipleChoiceField :Default widget is SelectMultiple
        FormHelper:This class controls form rendering behaviour of the form passed to {% crispy %} tag.
        To to do we need to set its attributes and pass corresponding helper object to tag.
    """
    Category = forms.ModelChoiceField(label="Category", queryset=Category.objects.all(), empty_label="Select Category")
    SecurityPatchLevel = forms.CharField(label="Security Patch level", max_length=100, required=False)
    Applicability = forms.CharField(label="Applicability", max_length=100)
    Description = forms.CharField(label="Description", max_length=100)
    LGSIDomainOwner = forms.ModelMultipleChoiceField(queryset=LGSIDomainOwner.objects.all())
    HQDomainOwner = forms.ModelMultipleChoiceField(queryset=HQDomainOwner.objects.all())
    OwnerShipStatus = forms.CharField(max_length=100)

    class Meta:
        model = GSP

    def __init__(self, *args, **kwargs):
        super(GSPSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_class = 'form-inline form-horizontal'
        self.helper.form_id = "gsp-search-form"
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-lg-2"
        self.helper.field_class = "col-lg-8"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False
        self.helper.layout = Layout(
            Field('Category', placeholder="Enter GSP Category"),
            Field('SecurityPatchLevel', placeholder="Enter Security Patch level"),
            Field('Applicability', placeholder="Enter Applicability"),
            Field('Description', placeholder="Enter Description"),
            Field('LGSIDomainOwner', placeholder="Select LGSIDomainOwner"),
            Field('HQDomainOwner', placeholder="Select HQ DomainOwner"),
            Field('OwnerShipStatus', placeholder="Enter OwnerShipStatus"),
        )


class AddGSPForm(ModelForm):
    """
        This class is used to add Google security patch for all the fields defined in Model
        To define the same , field attribute is set to the special value __all__
    """

    class Meta:
        model = GSP
        fields = '__all__'


class GSPTrackerForm(forms.Form):
    """
        A form created just to display some google security patch search fields
    """

    Category = forms.ModelChoiceField(label="Category", queryset=Category.objects.all(), empty_label="Select Category")
    SecurityPatchLevel = forms.CharField(label="Security Patch level", max_length=100, required=False)
    LGSIDomainOwner = forms.ModelMultipleChoiceField(queryset=LGSIDomainOwner.objects.all())
    HQDomainOwner = forms.ModelMultipleChoiceField(queryset=HQDomainOwner.objects.all())

    class Meta:
        model = GSP

    def __init__(self, *args, **kwargs):
        super(GSPTrackerForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_class = 'form-inline form-horizontal'
        self.helper.form_id = "gsp-tracker-form"
        self.helper.form_method = 'GET'
        self.helper.label_class = "col-lg-2"
        self.helper.field_class = "col-lg-8"
        self.helper.disable_csrf = True
        self.helper.form_show_labels = False
        self.helper.layout = Layout(
            Field('Category', placeholder="Enter GSP Category"),
            Field('SecurityPatchLevel', placeholder="Enter Security Patch level"),
            Field('LGSIDomainOwner', placeholder="Select LGSIDomainOwner"),
        )
