from django.conf.urls import url
from . import views
from django.contrib.auth.decorators import login_required

app_name = 'gspapp'

urlpatterns = [
    url(r'^login/$', views.login_view, name='login_view'),
    url(r'^$', login_required(views.logon_view, login_url='/gspapp/'), name='logon_view'),
    url(r'^addgsp/$', views.addgsp_view, name='addgsp_view'),
]
