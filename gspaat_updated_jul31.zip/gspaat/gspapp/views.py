from __future__ import unicode_literals

from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse, HttpResponseRedirect
from .forms import LoginForm, AddGSPForm, GSPSearchForm
from .models import GSP
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.views.generic import ListView
from django.contrib.auth import authenticate, login, logout
from django.template.response import TemplateResponse

# Create your views here.


def login_view(request):
    logout(request)
    page_title = "GSPTracker"
    loginpage_heading = "Google Security Patch Tracker"

    #   If this is a post request we need to process the form data

    username = password = ''
    redirect_to = request.GET.get('next', '/gspapp/')
    print("redirect_to:", redirect_to)
    form = LoginForm()

    if request.POST:
        print("check if request is POST")
        form = LoginForm(request.POST)

        username = request.POST['username']
        password = request.POST['password']

        print("username:", username)
        print("password:", password)

        '''authenticate(request=None, **credentials)
        Use authenticate to verify a set of credentials .It takes credentials as keyword arguments.username and password
        for default case, check them against each authentication backend and returns a user object if the credentials are
        valid for a backend.'''
        user = authenticate(request, username=username, password=password)
        
        print("request.user object:", request.user)
        print("is anonymous:", user.is_anonymous)
        print("is authenticated:", user.is_authenticated)

        if user is not None:
            print("logged in user is not None and user is active:")
            '''If you have an authenticated user you want to attach to current session - this is done with login function
            login saves used id in the session, using Django sessions framework '''
            login(request, user)

            remember_me = request.POST.get('remember_me', False)

            if remember_me == "on":
                ONE_MONTH = 30 * 24 * 60 * 60
                expiry = getattr(settings, "KEEP_LOGGED_DURATION", ONE_MONTH)
                request.session.set_expiry(expiry)
            else:
                request.session.set_expiry(0)

            return HttpResponseRedirect(redirect_to)

    context = {'form': form, 'page_title': page_title, 'loginpage_heading': loginpage_heading}
    return render(request, 'login.html', context)


@login_required(login_url='/gspapp/')
def logon_view(request, id=None):
    print("Inside logon_view:")

    page_title = "GSPTracker"

    if request.method == 'POST':
        form = LoginForm(request.POST)
        print("when request method is POST inside logon_view request:")

        if form.is_valid():
            print("checked whether requested form is valid or not:")
            form.save()
            return HttpResponseRedirect('/gspapp/')
    else:
        print("when request method is GET:")
        #form = GSPSearchForm(request.GET)
        #context = {'form': form}
        context = {'page_title': page_title}
        return render(request, 'GSPTracker.html', context)


@login_required(login_url='/gspapp/')
#@login_required(login_url='/gspapp/')
#@login_required(redirect_field_name='/gspapp/')
def addgsp(request, id=None):

    print("ID Inside Add Google Security Patch:", id)

    """
        This method is used to add Google Security Patch if it is GET request and edit or modify the existing
        Google security patch from GSP ListView if it is POST request.           
    """
    page_title = "GSPTracker"

    if id:
        action = 'edit'
        '''
            Calling get() on a given model Manager ,but it raises Http404 instead of the model Does not Exist exception.
        '''
        model = get_object_or_404(GSP, pk=id)

    else:
        action = 'add'
        model = GSP()

    message = ""

    if request.method == 'POST':
        print("Inside addgsp during POST request")
        form = AddGSPForm(request.POST, instance=model)

        if form.is_valid():
            print("Checking whether form is valid or not")
            form.save()
            return HttpResponseRedirect('/gspapp/addgsp')
    else:
        print("Inside addgsp during GET request")
        form = AddGSPForm(instance=model)

    context = {'form': form, 'Message': message, 'page_title': page_title, 'action': action}
    return render(request, 'AddGSP.html', context)


class GSPDCList(ListView):
    """
        This view is used to display the list of added Google security Patches using ListView to get the domain confirmation.
        paginate_by:An integer representing how many objects should display per page.
        queryset:It is list of items for a given model.Querysets allow us to read data from the database, filter it and read it.
        get_queryset():Get the list of items for this view. This must be an iterable and may be a queryset
        get_context_data: Returns context data to display list of objects
        context_object_name:Designates name of the variable to use in the context
        template_name:It is the name of template to load and render to inform the view which template to use.
        This template will be rendered against a context containing a variable called object_list that contains all
        the GSP
        filter: Returns a new query set containing objects that match the given loop up parameters
        i contains: Case insensitive containment test

    """

    print("Inside GSP Tracker List View:")
    model = GSP
    form_class = GSPSearchForm

    context_object_name = 'gspatches'   # Template variable used to access the list of google security patches
    template_name = "GSPDCList.html"
    paginate_by = 15
    gspatches = []
    form = form_class()


    def get_queryset(self):
        #self.Category = get_object_or_404(GSP, name=self.kwargs['Category'])
        gsp_list_queryset = GSP.objects.all()

        for item in self.request.GET:
            print("self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            if key == "Category" and value:
                #self.Category = get_object_or_404(GSP, name=self.kwargs['Category'])
                gsp_list_queryset = gsp_list_queryset.filter(Category__icontains='value')

            if key == "SecurityPatchlevel" and value:
                gsp_list_queryset = gsp_list_queryset.filter(Security_Patch_level__icontains='value')

            if key == "Applicability" and value:
                gsp_list_queryset = gsp_list_queryset.filter(Applicability__icontains='value')

            if key == "Description" and value:
                gsp_list_queryset = gsp_list_queryset.filter(Description__icontains='value')

            if key == "LGSIDomainOwner" and value:
                gsp_list_queryset = gsp_list_queryset.filter(LGSIDomainOwner__icontains='value')

            if key == "HQDomainOwner" and value:
                gsp_list_queryset = gsp_list_queryset.filter(HQDomainOwner__icontains='value')

            if key == "OwnerShipStatus" and value:
                gsp_list_queryset = gsp_list_queryset.filter(OwnerShipstatus__icontains='value')

        return gsp_list_queryset

    def get_context_data(self, **kwargs):
        """
            Calls the base implementation to first to get a context.
            Generally ,get_context_data will merge the context data of all parent classes with those of current class.
            To preserve this behaviour in your own classes where we want to alter the context , we should be sure to call
            the context on the super class

        """
        context = super(GSPDCList,self).get_context_data(**kwargs)
        context.update(**kwargs)

        context['form'] = GSPSearchForm(self.request.GET)
        searchq=""

        for item in self.request.GET:
            print("self.request.GET", self.request.GET)
            key = item
            value = self.request.GET.get(item)

            if key == "page":
                continue

            searchq += "%s=%s&" % (key, value)
        print("searchq:", searchq)
        context['searchq'] = searchq
        return context


def gsplist_view():
    pass


def applygsp_view():
    pass


def gspreview_view():
    pass
